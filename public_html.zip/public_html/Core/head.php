<!DOCTYPE HTML>
<html>
<head>
<title><?=servername;?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?=servername?>" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
 <!-- Bootstrap Core CSS -->
<link rel="shortcut icon" href="<?=favicon_logo;?>">
<link href="../assets/core/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="../assets/core/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="../assets/core/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<style type="text/css">
	@media(max-width:600px) and (min-width: 200px){
	    .logosize{
	        height: 80px !important;
	        
	    }
	}
	.logosize{
	    height: 100px !important;
	    width: 120px;
	}
</style>
</head> 