<?php
$error='';

$conn=new mysqli("localhost","boulders_mayur","kmphasis@123","boulders_bouldersmart");

define('servername','BoulderSmart');

define('logo',"https://".$_SERVER['HTTP_HOST']."/assets/images/logonew.png");

define('favicon_logo',"https://".$_SERVER['HTTP_HOST']."/assets/images/logo.png");
?>