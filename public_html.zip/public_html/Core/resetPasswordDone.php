<?PHP require_once("connect.php"); ?>

<?php require_once("head.php"); ?>
   
 <body class="sign-in-up">
    <section>
			<div id="page-wrapper" class="sign-in-wrapper">
				<div class="graphs">
					<div class="sign-in-form">
						<center><img src="<?=logo;?>" class="logosize" />	
						</center><br/>	
						
						<div class="signin" style="position: static;">
						
						
						<p style="color: green; text-align: center; font-size: 20px;">It seems that you have already reset your password.</p>
						
						<br/>
						
						</div>

					</div>
				</div>
			</div>
		<!--footer section start-->
			<?php require_once("footer.php"); ?>
		<!--footer section end-->
	</section>

<script src="../assets/core/bootstrap.min.js"></script>
</body>
</html>