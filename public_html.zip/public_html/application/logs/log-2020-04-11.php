<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-11 14:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-11 14:04:19 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-04-11 14:04:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-04-11 14:18:18 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-11 14:18:19 --> 404 Page Not Found: A/index
ERROR - 2020-04-11 14:18:20 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-11 14:18:22 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-11 14:18:26 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-11 14:18:27 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-11 14:18:28 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-11 14:18:28 --> 404 Page Not Found: A/index
ERROR - 2020-04-11 14:18:31 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-11 14:18:35 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-11 14:18:36 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-11 22:26:20 --> 404 Page Not Found: Robotstxt/index
