<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-19 11:44:47 --> 404 Page Not Found: Admin/index
ERROR - 2020-03-19 11:44:50 --> 404 Page Not Found: Manager/index
ERROR - 2020-03-19 11:44:54 --> 404 Page Not Found: Admin/content
ERROR - 2020-03-19 11:44:56 --> 404 Page Not Found: Simpla/index
ERROR - 2020-03-19 11:44:57 --> 404 Page Not Found: Js/mage
ERROR - 2020-03-19 14:19:19 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-19 14:19:28 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-19 14:19:29 --> 404 Page Not Found: A/index
