<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-13 09:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-13 14:25:12 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-13 14:25:12 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-13 14:25:15 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-13 14:25:19 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-13 14:25:21 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-13 14:25:23 --> 404 Page Not Found: A/index
ERROR - 2020-04-13 14:25:28 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-13 14:25:29 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-13 14:25:30 --> 404 Page Not Found: A/index
