<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-01 06:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-01 06:36:19 --> 404 Page Not Found: Humanstxt/index
ERROR - 2020-05-01 06:36:20 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-05-01 14:18:41 --> 404 Page Not Found: Admin/index
ERROR - 2020-05-01 14:23:08 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-05-01 14:23:09 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-05-01 14:23:12 --> 404 Page Not Found: Login/.http:
ERROR - 2020-05-01 14:23:19 --> 404 Page Not Found: A/index
ERROR - 2020-05-01 14:23:20 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
ERROR - 2020-05-01 14:23:20 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-05-01 14:23:24 --> 404 Page Not Found: Login/.http:
