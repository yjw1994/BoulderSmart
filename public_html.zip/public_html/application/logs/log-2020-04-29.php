<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-29 19:08:58 --> 404 Page Not Found: App-adstxt/index
