<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-12 08:02:33 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-03-12 14:17:31 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-12 14:17:32 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-12 14:17:33 --> 404 Page Not Found: A/index
ERROR - 2020-03-12 14:17:42 --> 404 Page Not Found: A/index
