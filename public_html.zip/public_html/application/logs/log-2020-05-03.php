<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-03 05:41:29 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2020-05-03 11:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-05-03 14:22:52 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-05-03 14:22:53 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-05-03 14:22:56 --> 404 Page Not Found: A/index
ERROR - 2020-05-03 14:22:58 --> 404 Page Not Found: Login/.http:
ERROR - 2020-05-03 14:22:59 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
ERROR - 2020-05-03 18:41:25 --> 404 Page Not Found: Scripts/jquery.min.js
ERROR - 2020-05-03 18:41:26 --> 404 Page Not Found: Assets/fonts
