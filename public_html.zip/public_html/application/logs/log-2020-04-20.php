<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-20 01:16:41 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2020-04-20 01:16:43 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2020-04-20 01:16:43 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2020-04-20 01:16:44 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2020-04-20 01:16:44 --> 404 Page Not Found: Site/wp-includes
ERROR - 2020-04-20 01:16:45 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2020-04-20 01:44:21 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-04-20 08:00:09 --> 404 Page Not Found: Blog/index
ERROR - 2020-04-20 13:18:31 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-04-20 14:25:53 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-20 14:26:01 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-20 14:26:02 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-20 14:26:03 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
ERROR - 2020-04-20 14:26:03 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-20 14:26:09 --> 404 Page Not Found: A/index
