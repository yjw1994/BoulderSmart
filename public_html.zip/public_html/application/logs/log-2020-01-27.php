<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-27 09:20:18 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:20:24 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:20:28 --> 404 Page Not Found: Assets/cover_image
ERROR - 2020-01-27 09:20:28 --> 404 Page Not Found: Assets/cover_image
ERROR - 2020-01-27 09:20:28 --> 404 Page Not Found: Assets/cover_image
ERROR - 2020-01-27 09:20:28 --> 404 Page Not Found: Assets/cover_image
ERROR - 2020-01-27 09:20:31 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:21:16 --> Query error: Table 'boulders_bouldersmart.voucher_master' doesn't exist - Invalid query: select *,IF(voucher_image != '',concat('http://bouldersmartapplication.space/BoulderSmart/assets/voucher_image/', voucher_image),'') as voucher_image FROM voucher_master WHERE is_delete='0' ORDER BY voucher_id DESC
ERROR - 2020-01-27 09:21:31 --> Query error: Table 'boulders_bouldersmart.location_master' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `location_master`
WHERE 1 = 1
ERROR - 2020-01-27 09:22:06 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:22:06 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:22:06 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 09:22:06 --> 404 Page Not Found: Assets/voucher_image
ERROR - 2020-01-27 10:06:30 --> 404 Page Not Found: Http:/bouldersmartapplication.space
ERROR - 2020-01-27 12:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-01-27 15:15:50 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-01-27 15:15:51 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-01-27 15:15:58 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
