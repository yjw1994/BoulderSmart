<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 11:37:53 --> 404 Page Not Found: Admin/index
ERROR - 2020-04-01 14:24:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-01 14:24:12 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-01 14:24:14 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-01 14:24:15 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-01 14:24:17 --> 404 Page Not Found: A/index
ERROR - 2020-04-01 14:24:22 --> 404 Page Not Found: Login/.http:
