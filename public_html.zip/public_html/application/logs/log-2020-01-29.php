<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-29 06:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-01-29 15:17:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-01-29 15:17:12 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
