<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-25 14:23:37 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-25 14:23:39 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-25 14:23:47 --> 404 Page Not Found: A/index
