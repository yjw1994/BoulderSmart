<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-07 15:25:23 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-07 15:25:24 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-07 15:25:27 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-07 15:25:32 --> 404 Page Not Found: A/index
