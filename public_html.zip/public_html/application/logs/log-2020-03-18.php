<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-18 14:22:40 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-18 14:22:40 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-18 14:22:46 --> 404 Page Not Found: A/index
ERROR - 2020-03-18 14:22:50 --> 404 Page Not Found: A/index
