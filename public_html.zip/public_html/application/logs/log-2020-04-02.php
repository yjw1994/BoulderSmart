<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-02 12:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-02 14:17:53 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-02 14:18:03 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-02 14:18:04 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-02 14:18:04 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-02 14:18:10 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-02 14:18:11 --> 404 Page Not Found: A/index
