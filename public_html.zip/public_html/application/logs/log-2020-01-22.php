<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 17:39:00 --> Query error: Table 'bouldersmart.property_master' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `property_master`
WHERE 1 = 1
ERROR - 2020-01-22 17:40:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 17:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 17:43:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 17:43:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 17:43:31 --> 404 Page Not Found: User/index
ERROR - 2020-01-22 17:43:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 17:43:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:16:58 --> 404 Page Not Found: User/index
ERROR - 2020-01-22 18:17:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:17:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:17:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:20:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'location_master lm LEFT JOIN user_master um ON um.user_id = lm.user_id' at line 1 - Invalid query: select * location_master lm LEFT JOIN user_master um ON um.user_id = lm.user_id
ERROR - 2020-01-22 18:23:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:23:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:25:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-22 18:27:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IF(cover_image != '',concat('http://localhost/BoulderSmart/assets/cover_image/',' at line 1 - Invalid query: select *,,IF(cover_image != '',concat('http://localhost/BoulderSmart/assets/cover_image/', cover_image),'') as cover_image FROM location_master lm LEFT JOIN user_master um ON um.user_id = lm.user_id
