<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-16 10:31:12 --> 404 Page Not Found: Administrator/index.php
ERROR - 2020-04-16 10:31:13 --> 404 Page Not Found: Admin/index
ERROR - 2020-04-16 10:31:13 --> 404 Page Not Found: Admin/login.php
ERROR - 2020-04-16 10:31:14 --> 404 Page Not Found: Admin/index.php
ERROR - 2020-04-16 12:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-16 14:17:45 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-16 14:17:46 --> 404 Page Not Found: A/index
ERROR - 2020-04-16 14:17:47 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-16 14:17:48 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
ERROR - 2020-04-16 14:17:50 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-16 14:17:51 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-16 14:18:03 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-16 14:18:03 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-16 14:18:04 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
