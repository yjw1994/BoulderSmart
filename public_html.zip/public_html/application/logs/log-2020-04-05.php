<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-05 14:26:24 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-05 14:26:24 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-05 14:26:25 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-05 14:26:29 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-05 14:26:33 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-05 14:26:34 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-05 14:26:36 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-05 23:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 23:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 23:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-04-05 23:27:04 --> 404 Page Not Found: Robotstxt/index
