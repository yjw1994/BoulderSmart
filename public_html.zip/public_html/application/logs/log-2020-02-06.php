<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-06 03:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-06 07:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-06 15:24:16 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-06 15:24:25 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-06 15:24:28 --> 404 Page Not Found: A/index
ERROR - 2020-02-06 15:24:32 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-06 15:24:33 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-06 15:24:34 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
