<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-23 10:01:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:01:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:02:35 --> 404 Page Not Found: Location/edit_loc
ERROR - 2020-01-23 10:02:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:03:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:05:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:06:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:07:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:08:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:08:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:09:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:09:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:09:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:37:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 10:38:35 --> 404 Page Not Found: Routes/3
ERROR - 2020-01-23 10:39:15 --> 404 Page Not Found: Routes/3
ERROR - 2020-01-23 11:22:12 --> Query error: Table 'bouldersmart.1route_ratting_master' doesn't exist - Invalid query: SELECT (ratting) as averageratting
FROM `1route_ratting_master`
WHERE `route_id` = '1'
AND `user_id` IS NULL
ERROR - 2020-01-23 11:45:26 --> Query error: Unknown column '1*' in 'field list' - Invalid query: SELECT `1*`, IF(cover_image != '', concat('http://localhost/BoulderSmart/assets/cover_image/', cover_image), '') as cover_image
FROM `location_master`
WHERE `user_id` IS NULL
AND `is_admin_confirm` = 1
ERROR - 2020-01-23 11:55:08 --> Query error: Table 'bouldersmart.1route_ratting_master' doesn't exist - Invalid query: UPDATE `1route_ratting_master` SET `route_id` = '1', `user_id` = '1', `ratting` = '3', `comments` = 'Testing commnets', `updated_date` = '2020-01-23 11:55:08'
WHERE `ratting_id` IS NULL
ERROR - 2020-01-23 12:49:40 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT `um`.`fname`, `um`.`lname`, `ratting`, `comments`
FROM `route_ratting_master` `rm`
LEFT JOIN `user_master` `um` ON `um`.`user_id`=`rm`.`user_id`
WHERE `route_id` = '5'
AND `user_id` = '1'
ORDER BY `ratting_id` DESC
ERROR - 2020-01-23 12:50:07 --> Query error: Column 'user_id' in where clause is ambiguous - Invalid query: SELECT `um`.`fname`, `um`.`lname`, `rm`.`ratting`, `rm`.`comments`
FROM `route_ratting_master` `rm`
LEFT JOIN `user_master` `um` ON `um`.`user_id`=`rm`.`user_id`
WHERE `route_id` = '5'
AND `user_id` = '1'
ORDER BY `ratting_id` DESC
ERROR - 2020-01-23 16:58:20 --> Query error: Unknown column 'photo' in 'field list' - Invalid query: INSERT INTO `approach_master` (`user_id`, `location_id`, `approach_name`, `photo`, `created_date`, `updated_date`) VALUES ('1', '1', 'test', '5e2983542644d_routeimage_1579778900.jpeg', '2020-01-23 16:58:20', '2020-01-23 16:58:20')
ERROR - 2020-01-23 17:01:19 --> Severity: error --> Exception: syntax error, unexpected ''approach_name'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 1281
ERROR - 2020-01-23 17:01:56 --> Severity: error --> Exception: syntax error, unexpected ''approach_name'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 1281
ERROR - 2020-01-23 17:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 17:24:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 17:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 17:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 17:31:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:10:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY voucher_id DESC' at line 1 - Invalid query: select *,IF(voucher_image != '',concat('http://localhost/BoulderSmart/assets/voucher_image/', voucher_image),'') as voucher_image FROM voucher_master lm  WHERE ORDER BY voucher_id DESC
ERROR - 2020-01-23 18:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:15:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:15:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:16:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:17:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:17:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:17:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:17:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:18:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:18:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:18:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:18:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:19:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:19:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:25:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-01-23 18:25:32 --> 404 Page Not Found: Assets/js
