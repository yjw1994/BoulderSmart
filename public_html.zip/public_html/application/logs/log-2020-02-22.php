<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-22 03:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-22 15:17:29 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-22 15:17:31 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-22 15:17:42 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-22 15:17:43 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
