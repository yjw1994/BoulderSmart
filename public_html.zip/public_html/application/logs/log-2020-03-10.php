<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-10 14:17:01 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-10 14:17:02 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-10 14:17:09 --> 404 Page Not Found: A/index
