<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-03 15:27:46 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-03 15:27:47 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-03 15:27:51 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-03 15:27:52 --> 404 Page Not Found: A/index
ERROR - 2020-03-03 15:27:55 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-03 15:27:56 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
