<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-24 09:58:28 --> 404 Page Not Found: Assets/js
