
<?php require_once("include/head.php"); ?>

  <body class="fixed-sidebar fixed-header skin-default content-appear">
    <div class="wrapper">
      <!-- Sidebar -->
        
      <?php require_once("include/sidebar.php"); ?>     
      
      <?php require_once("include/header.php"); ?>

      <div class="site-content">
        <!-- Content -->
        <div class="content-area py-1">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10">
                <h4>Users</h4>
                <ol class="breadcrumb no-bg mb-1">
                  <li class="breadcrumb-item"><a href="<?=base_url().'Home'?>">Home</a></li>
                  <li class="breadcrumb-item active">Users</li>
                </ol>
              </div>
              
              <div class="col-md-2"></div>
            </div>
            
            
            <div class="box box-block bg-white">
              
              <table id="user_tbl" class="table table-striped table-borderd table-hover">

                  <thead>
                    <tr>
                      <th style="width:10%;">Sr. No.</th>
                      <th style="width:25%;">First Name</th>
                      <th style="width:25%;">Last Name</th>
                      <th style="width:30%;">Email</th>
                      <th style="width:10%;">Reward  Point</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach ($userList as $key => $value) {
                      ?>
                    <tr>
                      <td><?=($key+1);?></td>
                      <td><?=$value->fname?></td>
                      <td><?=$value->lname?></td>
                      <td><?=$value->email?></td>
                      <td><?=$value->reward_point?></td>
                     
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
            </div>            
          </div>
        </div>
        
        
      </div>
      

    </div>


  <!-- javascripts -->
  <?php require_once("include/all_script.php"); ?>

  <script type="text/javascript">
    jQuery(document).ready( function () {

          var dataTable = $('#user_tbl').DataTable({"autoWidth": false});

    });

   

</script>  

</body>

</html>
