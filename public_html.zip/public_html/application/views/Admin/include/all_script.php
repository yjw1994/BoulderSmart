        <script type="text/javascript" src="<?=base_url()?>assets/js/jquery-1.12.3.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/tether.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/detectmobilebrowser.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.mousewheel.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/mwheelIntent.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.jscrollpane.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.fullscreen-min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/waves.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/switchery.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.flot.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.flot.resize.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.flot.tooltip.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/curvedLines.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/tinycolor.js"></script>
		
		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.peity.js"></script>


		<script type="text/javascript" src="<?=base_url()?>assets/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/dataTables.bootstrap4.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/dataTables.responsive.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/responsive.bootstrap4.min.js"></script>
		<script type="text/javascript" src=".<?=base_url()?>assets/js/dataTables.buttons.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/buttons.bootstrap4.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/jszip.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/buttons.html5.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/buttons.print.min.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/buttons.colVis.min.js"></script>
		
		<script type="text/javascript" src="<?=base_url()?>assets/js/app.js"></script>
		<script type="text/javascript" src="<?=base_url()?>assets/js/demo.js"></script>
		<!-- <script type="text/javascript" src="<?=base_url()?>assets/js/index.js"></script> -->		

		<script type="text/javascript" src="<?=base_url()?>assets/js/tables-datatable.js"></script>

		<script src='http://maps.googleapis.com/maps/api/js?v=3&libraries=places&key=AIzaSyCRaD-kSb9C0jdLuwRGpHesl8TjuPbcj0I'></script>

		<style>
                  .pac-container {
                      z-index: 10000 !important;
                  }
                  .center-block{
                      margin-left: 10%;
                  }
        </style>

        <script type="text/javascript">
		    $(document).ready(function() {
		          $('body').on('keypress','.numbers', function(event){
		               return isNumber(event, this)
		          });

		          function isNumber(evt, element) {

		            var charCode = (evt.which) ? evt.which : evt.keyCode
		            //alert(charCode);
		            if ( (charCode >= 48 && charCode <= 57) || (charCode == 32) || (charCode == 43)|| (charCode == 40) || (charCode == 41))
		                return true;

		            return false;
		          }

		         
		    });

		    function sendData()
		    {  
		      var fi = document.getElementById('img'); 
		        if (fi.files.length > 0) {         
		            var oFReader = new FileReader();
		            oFReader.readAsDataURL(document.getElementById("img").files[0]);
		            oFReader.onload = function (oFREvent) {
		            document.getElementById("imgUpload").src = oFREvent.target.result;
		          }
		      }
		    }

		    function sendData_add()
		    {  
		      var fi = document.getElementById('img_add'); 
		        if (fi.files.length > 0) {         
		            var oFReader = new FileReader();
		            oFReader.readAsDataURL(document.getElementById("img_add").files[0]);
		            oFReader.onload = function (oFREvent) {
		            document.getElementById("imgUpload_add").src = oFREvent.target.result;
		          }
		      }
		    }


		    //Find addres by google api
		    function findAddress() 
		    {
		        var input = document.getElementById('adress');
		        var autocomplete = new google.maps.places.Autocomplete(input); 
		        google.maps.event.addListener(autocomplete, 'place_changed', function () {
		        var place = autocomplete.getPlace();
		        document.getElementById('latitude').value = place.geometry.location.lat();
		        document.getElementById('longitude').value = place.geometry.location.lng();
		                
		        });
		    }

		    
		</script>