<?php
   $lang['msg'] = "Exemple CodeIgniter internationalisation.";
?>