<?php
ob_start();
error_reporting(0);
class Lang_controller extends CI_Controller {

	public function index(){
		 //Get the selected language
		 $language = $this->input->post('language');
		 
		 if ($language == "" || $language == NULL) {
		 	$language = "english";
		 }
		 //Choose language file according to selected lanaguage
		 $this->lang->load($language.'_lang',$language);

		 //Fetch the message from language file.
		 $data['msg'] = $this->lang->line('msg');

		 $data['language'] = $language;
		 //Load the view file
		 $this->load->view('lang_view',$data);
	}
}	