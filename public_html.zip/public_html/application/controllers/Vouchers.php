<?php
ob_start();
error_reporting(0);
class Vouchers extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }
	
	public function index()
	{
		if($this->session->userdata('sess_id'))
		{
		 	
		 	$imageurl = base_url().'assets/voucher_image/';
		 	$data['voucherList']=$this->model->querydata("select *,IF(voucher_image != '',concat('$imageurl', voucher_image),'') as voucher_image FROM voucher_master WHERE is_delete='0' ORDER BY voucher_id DESC");

		 	$this->load->view('Admin/vouchers',$data);

		 	if ($this->input->post("add_voucher")) {
		 		extract($_POST);

		 		
				$voucher_image = $_FILES['voucher_image']['name'];
		 		if($voucher_image!="" && $voucher_image!=NULL){
                    if (!file_exists('assets/voucher_image/')) {
                        mkdir('assets/voucher_image/', 0777, true);
                    }

                    $ext= pathinfo($voucher_image, PATHINFO_EXTENSION);
                    $newname=uniqid()."_voucherimage_".time().".".$ext;
                    $tmpname=$_FILES['voucher_image']['tmp_name'];
                    move_uploaded_file($tmpname, "assets/voucher_image/".$newname);
                }
                else{
                  $newname="";
                }

               $this->model->insert("voucher_master",array("voucher_name"=>$voucher_name,"discount"=>$discount,"points"=>$points,"voucher_code"=>$voucher_code,"voucher_image"=>$newname,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));

               redirect(current_url());

		 	}
		 	if ($this->input->post("update_voucher")) {
		 		extract($_POST);

		 		$voucher_id = $this->input->post("voucher_id");
				$getvoucher =$this->model->sel_row("voucher_master",array("voucher_id"=>$voucher_id));
				$voucher_image = $_FILES['voucher_image']['name'];
		 		if($voucher_image!="" && $voucher_image!=NULL){
                    if (!file_exists('assets/voucher_image/')) {
                        mkdir('assets/voucher_image/', 0777, true);
                    }

                    $ext= pathinfo($voucher_image, PATHINFO_EXTENSION);
                    $newname=uniqid()."_voucherimage_".time().".".$ext;
                    $tmpname=$_FILES['voucher_image']['tmp_name'];
                    move_uploaded_file($tmpname, "assets/voucher_image/".$newname);
                }
                else{
                  $newname=$getvoucher->voucher_image;
                }

               $this->model->update("voucher_master",array("voucher_name"=>$voucher_name,"discount"=>$discount,"points"=>$points,"voucher_code"=>$voucher_code,"voucher_image"=>$newname,"updated_date"=>cur_date_time),array("voucher_id"=>$voucher_id));

               redirect(current_url());

		 	}
		}
		else
		{
			redirect(base_url());	
		}	
	}


	public function editVoucher()
	{
		$voucher_id = $this->uri->segment(3);
		$imageurl = base_url().'assets/voucher_image/';
		$getvoucher =$this->model->sel_fld_row("*,IF(voucher_image != '',concat('$imageurl', voucher_image),'') as voucher_image","voucher_master",array("voucher_id"=>$voucher_id));
		if ($getvoucher->voucher_image != "") {
			$image = $getvoucher->voucher_image;
		}
		else
		{
			$image = base_url()."assets/images/defaultImg.png";
		}
		

		?>
		<form class="modal-content" method="post" enctype="multipart/form-data">
              
	        <div class="modal-header"> 
	          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	            <span aria-hidden="true">x</span>
	          </button>
	          <h4 class="modal-title" id="exampleFormModalLabel">Edit Voucher</h4>
	        </div>
	        <div class="modal-body">
	                
	                 <div class="form-group">
	                    <div class="row">
	                    <div class="col-md-6 col-sm-6 col-xs-6 col-md-offset-5 col-sm-offset-4 col-xs-offset-4">
	                       <label for="img">
	                          <img id="imgUpload" src="<?=$image?>" alt="Cover Image" style="cursor: pointer; height: 100px; width: 100px;" />
	                        </label>
	                          <input id="img" type="file" accept="image/*" name="voucher_image" style="display:none;" onChange="return sendData()"/>
	                        
	                    </div>
	                    <div class="clearfix"> </div>
	                     </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Voucher Name" name="voucher_name" value="<?=$getvoucher->voucher_name;?>" required="required" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>
	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Voucher Code" name="voucher_code" value="<?=$getvoucher->voucher_code;?>" required="required" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                  
	                   <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-6 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control numbers" placeholder="Points" name="points" required="required"  value="<?=$getvoucher->points;?>" />
	                      </div>

	                       <div class="col-md-6 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control numbers" min="1" max="100" placeholder="Discount" name="discount" required="required" value="<?=$getvoucher->discount;?>" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                  <input type="hidden" name="voucher_id" value="<?=$voucher_id?>">
	              
	        </div>
	        <div class="modal-footer">
	          <input type="submit" name="update_voucher" class="btn btn-primary" value="Update"/>
	        </div>  
	      </form>
		<?php

	}

	public function deleteVoucher()
	{
		$voucher_id = $this->uri->segment(3);
        $this->model->update("voucher_master",array("is_delete"=>1,"updated_date"=>cur_date_time),array("voucher_id"=>$voucher_id));
	}

  

}