<?php
ob_start();
error_reporting(0);
class Location extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }
	
	public function index()
	{
		if($this->session->userdata('sess_id'))
		{
		 	
		 	$imageurl = base_url().'assets/cover_image/';
		 	$data['locationList']=$this->model->querydata("select *,IF(cover_image != '',concat('$imageurl', cover_image),'') as cover_image FROM location_master lm LEFT JOIN user_master um ON um.user_id = lm.user_id WHERE um.is_delete='0' ORDER BY location_id DESC");

		 	$this->load->view('Admin/location',$data);

		 	if ($this->input->post("update_location")) {
		 		extract($_POST);

		 		$location_id = $this->input->post("location_id");
				$getlocation =$this->model->sel_row("location_master",array("location_id"=>$location_id));
				$cover_image = $_FILES['cover_image']['name'];
		 		if($cover_image!="" && $cover_image!=NULL){
                    if (!file_exists('assets/cover_image/')) {
                        mkdir('assets/cover_image/', 0777, true);
                    }

                    $ext= pathinfo($cover_image, PATHINFO_EXTENSION);
                    $newname=uniqid()."_coverimage_".time().".".$ext;
                    $tmpname=$_FILES['cover_image']['tmp_name'];
                    move_uploaded_file($tmpname, "assets/cover_image/".$newname);
                }
                else{
                  $newname=$getlocation->cover_image;
                }

               $this->model->update("location_master",array("location_name"=>$location_name,"adress"=>$adress,"lat"=>$lat,"lng"=>$lng,"cover_image"=>$newname,"updated_date"=>cur_date_time),array("location_id"=>$location_id));

               redirect(current_url());

		 	}
		}
		else
		{
			redirect(base_url());	
		}	
	}

	

	public function requestStatus()
	{
		$location_id = $this->input->post("location_id");
		$user_id = $this->input->post("user_id");
		$status = $this->input->post("status");
		$getUser = $this->model->sel_row("user_master",array("user_id"=>$user_id));
		$scExit = 0;
		$rewardpoint =$this->session->userdata("req_approve_point");
		if ($status == "1") {
			$this->model->update("location_master",array("is_admin_confirm"=>1),array("location_id"=>$location_id));
			$this->model->update("user_master",array("reward_point"=>$getUser->reward_point+$rewardpoint),array("user_id"=>$user_id));
			$scExit = 1;
		}
		echo $scExit;
	}

	public function editLocation()
	{
		$location_id = $this->uri->segment(3);
		$imageurl = base_url().'assets/cover_image/';
		$getlocation =$this->model->sel_fld_row("*,IF(cover_image != '',concat('$imageurl', cover_image),'') as cover_image","location_master",array("location_id"=>$location_id));
		if ($getlocation->cover_image != "") {
			$image = $getlocation->cover_image;
		}
		else
		{
			$image = base_url()."assets/images/defaultImg.png";
		}
		

		?>
		<form class="modal-content" method="post" enctype="multipart/form-data">
              
	        <div class="modal-header"> 
	          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	            <span aria-hidden="true">x</span>
	          </button>
	          <h4 class="modal-title" id="exampleFormModalLabel">Edit Location</h4>
	        </div>
	        <div class="modal-body">
	                
	                 <div class="form-group">
	                    <div class="row">
	                    <div class="col-md-6 col-sm-6 col-xs-6 col-md-offset-5 col-sm-offset-4 col-xs-offset-4">
	                       <label for="img">
	                          <img id="imgUpload" src="<?=$image?>" alt="Cover Image" style="cursor: pointer; height: 100px; width: 100px;" />
	                        </label>
	                          <input id="img" type="file" accept="image/*" name="cover_image" style="display:none;" onChange="return sendData()"/>
	                        
	                    </div>
	                    <div class="clearfix"> </div>
	                     </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Name" name="location_name" value="<?=$getlocation->location_name;?>" required="required" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Address" name="adress" id="adress" required="required"  onFocus="findAddress()" value="<?=$getlocation->adress;?>" id="location" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                   <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-6 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control numbers" placeholder="Latitude" name="lat" required="required"  id="latitude" value="<?=$getlocation->lat;?>" readonly />
	                      </div>

	                       <div class="col-md-6 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control numbers" placeholder="Longitude" name="lng" required="required"  id="longitude" value="<?=$getlocation->lng;?>" readonly />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                  <input type="hidden" name="location_id" value="<?=$location_id?>">
	              
	        </div>
	        <div class="modal-footer">
	          <input type="submit" name="update_location" class="btn btn-primary" value="Update"/>
	        </div>  
	      </form>
		<?php

	}

	public function deleteLocation()
	{
		$location_id = $this->uri->segment(3);
		$this->model->delete("route_master",array("location_id"=>$location_id));
        $this->model->delete("location_master",array("location_id"=>$location_id));
	}

	public function RouteList()
	{
		if($this->session->userdata('sess_id'))
		{
			$locationid= $this->uri->segment(3);
			$imageurl = base_url().'assets/route_image/';
		 	$data['routeList']=$this->model->querydata("select rm.*,um.*,lm.location_name,IF(photo != '',concat('$imageurl', photo),'') as photo FROM route_master rm LEFT JOIN location_master lm ON lm.location_id=rm.location_id LEFT JOIN user_master um ON um.user_id = lm.user_id WHERE um.is_delete='0' AND rm.location_id='$locationid' ORDER BY route_id DESC");
		 	$this->load->view('Admin/route',$data);

		 	if ($this->input->post("update_route")) {
			 		extract($_POST);

			 		$route_id = $this->input->post("route_id");
					$getRoute =$this->model->sel_row("route_master",array("route_id"=>$route_id));
					$route_image = $_FILES['route_image']['name'];
			 		if($route_image!="" && $route_image!=NULL){
	                    if (!file_exists('assets/route_image/')) {
	                        mkdir('assets/route_image/', 0777, true);
	                    }

	                    $ext= pathinfo($route_image, PATHINFO_EXTENSION);
	                    $newname=uniqid()."_routeimage_".time().".".$ext;
	                    $tmpname=$_FILES['route_image']['tmp_name'];
	                    move_uploaded_file($tmpname, "assets/route_image/".$newname);
	                }
	                else{
	                  $newname=$getRoute->photo;
	                }

	               $this->model->update("route_master",array("route_name"=>$route_name,"grade_opinion"=>$grade_opinion,"photo"=>$newname,"updated_date"=>cur_date_time),array("route_id"=>$route_id));

	               redirect(current_url());

			}
		}
		else
		{
			redirect(base_url());
		}
	 	
	}




  

}