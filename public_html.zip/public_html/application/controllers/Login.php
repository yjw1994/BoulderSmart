<?php
ob_start();
error_reporting(0);
class Login extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }

	public function index()
	{
	    if(!$this->session->userdata('sess_id'))
		{
    		$this->load->view('Admin/login');
    
    		if($this->input->post('login')){			
            	$email=$this->input->post('email');
    			$pass=md5($this->input->post('password'));
    			$pass1=$this->input->post('password');
    			$rem=$this->input->post('rem');
    
    			$data=array("email"=>$email,"password"=>$pass);
    
    			$admindata=$this->model->sel_row("admin_master",$data);
    			$total_admin=$this->model->record_count("admin_master",$data);
    
    			if($total_admin>0){
    					$datas=array("sess_id"=>$admindata->id,"req_approve_point"=>$admindata->req_approve_point);
    					$this->session->set_userdata($datas);
    					if($rem=="rem_email_pas"){
    						setcookie("lc_mail", $email,strtotime('+1 month'));
    						setcookie("lc_pass", $pass1,strtotime('+1 month'));
    					}
    					
    						redirect(base_url()."Home");	
    					
    			}
    			else{
    				$this->session->set_userdata('error', 'Incorrect Email or Password.');
    				redirect(base_url());
    			}
    		}
		}
		else
		{
			redirect(base_url().'Home');	
		}
	}

	public function logout()
	{
		$this->session->sess_destroy();	
		redirect(base_url());	
	}


}

?>