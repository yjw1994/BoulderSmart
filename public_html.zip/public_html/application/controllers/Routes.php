<?php
ob_start();
error_reporting(0);
class Routes extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }
	
	public function index()
	{
		if($this->session->userdata('sess_id'))
		{
		 	
		 	$imageurl = base_url().'assets/route_image/';
		 	$data['routeList']=$this->model->querydata("select rm.*,um.*,lm.location_name,IF(photo != '',concat('$imageurl', photo),'') as photo FROM route_master rm LEFT JOIN location_master lm ON lm.location_id=rm.location_id LEFT JOIN user_master um ON um.user_id = lm.user_id WHERE um.is_delete='0' ORDER BY route_id DESC");

		 	$this->load->view('Admin/route',$data);

		 	if ($this->input->post("update_route")) {
		 		extract($_POST);

		 		$route_id = $this->input->post("route_id");
				$getRoute =$this->model->sel_row("route_master",array("route_id"=>$route_id));
				$route_image = $_FILES['route_image']['name'];
		 		if($route_image!="" && $route_image!=NULL){
                    if (!file_exists('assets/route_image/')) {
                        mkdir('assets/route_image/', 0777, true);
                    }

                    $ext= pathinfo($route_image, PATHINFO_EXTENSION);
                    $newname=uniqid()."_routeimage_".time().".".$ext;
                    $tmpname=$_FILES['route_image']['tmp_name'];
                    move_uploaded_file($tmpname, "assets/route_image/".$newname);
                }
                else{
                  $newname=$getRoute->photo;
                }

               $this->model->update("route_master",array("route_name"=>$route_name,"grade_opinion"=>$grade_opinion,"photo"=>$newname,"updated_date"=>cur_date_time),array("route_id"=>$route_id));

               redirect(current_url());

		 	}
		}
		else
		{
			redirect(base_url());	
		}	
	}

	

	public function requestStatus()
	{
		$route_id = $this->input->post("route_id");
		$user_id = $this->input->post("user_id");
		$status = $this->input->post("status");
		$rewardpoint =$this->session->userdata("req_approve_point");
		$getUser = $this->model->sel_row("user_master",array("user_id"=>$user_id));
		$scExit = 0;
		if ($status == "1") {
			$this->model->update("route_master",array("is_admin_confirm"=>1),array("route_id"=>$route_id));
			$this->model->update("user_master",array("reward_point"=>$getUser->reward_point+$rewardpoint),array("user_id"=>$user_id));
			$scExit = 1;
		}
		echo $scExit;
	}

	public function editRoute()
	{
		$route_id = $this->uri->segment(3);
		$imageurl =base_url().'assets/route_image/';
		$getRoute =$this->model->sel_fld_row("*,IF(photo != '',concat('$imageurl', photo),'') as photo","route_master",array("route_id"=>$route_id));
		if ($getRoute->photo != "") {
			$image = $getRoute->photo;
		}
		else
		{
			$image = base_url()."assets/images/defaultImg.png";
		}
		

		?>
		<form class="modal-content" method="post" enctype="multipart/form-data">
              
	        <div class="modal-header"> 
	          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	            <span aria-hidden="true">x</span>
	          </button>
	          <h4 class="modal-title" id="exampleFormModalLabel">Edit Route</h4>
	        </div>
	        <div class="modal-body">
	                
	                 <div class="form-group">
	                    <div class="row">
	                    <div class="col-md-6 col-sm-6 col-xs-6 col-md-offset-5 col-sm-offset-4 col-xs-offset-4">
	                       <label for="img">
	                          <img id="imgUpload" src="<?=$image?>" alt="Route Image" style="cursor: pointer; height: 100px; width: 100px;" />
	                        </label>
	                          <input id="img" type="file" accept="image/*" name="route_image" style="display:none;" onChange="return sendData()"/>
	                        
	                    </div>
	                    <div class="clearfix"> </div>
	                     </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Name" name="route_name" value="<?=$getRoute->route_name;?>" required="required" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>

	                  <div class="form-group">
	                    <div class="row">
	                      <div class="col-md-12 col-sm-12 col-xs-12">
	                        <input type="text" class="form-control" placeholder="Grade opinion" name="grade_opinion"  required="required" value="<?=$getRoute->grade_opinion;?>" />
	                      </div>
	                      <div class="clearfix"> </div>
	                    </div>
	                  </div>


	                  <input type="hidden" name="route_id" value="<?=$route_id?>">
	              
	        </div>
	        <div class="modal-footer">
	          <input type="submit" name="update_route" class="btn btn-primary" value="Update"/>
	        </div>  
	      </form>
		<?php

	}

	public function deleteRoute()
	{
		$route_id = $this->uri->segment(3);
		$this->model->delete("route_master",array("route_id"=>$route_id));
	}

	
  

}