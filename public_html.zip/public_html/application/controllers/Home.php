<?php
ob_start();
error_reporting(0);
class Home extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }
	
	public function index()
	{
		if($this->session->userdata('sess_id'))
		{
		 	
		 	
		 	$data['user_total']=$this->model->record_count("user_master",array("is_confirm"=>1,"is_delete"=>0));

		 	$data['location_total']=$this->model->record_count("location_master",array(1=>1));

		 	$data['voucher_total']=$this->model->record_count("voucher_master",array("is_delete"=>0));

		 	

		 	$this->load->view('Admin/home',$data);
		}
		else
		{
			redirect(base_url());	
		}	
	}



  

}		