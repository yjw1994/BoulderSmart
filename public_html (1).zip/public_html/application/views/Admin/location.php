
<?php require_once("include/head.php"); ?>

  <body class="fixed-sidebar fixed-header skin-default content-appear">
    <div class="wrapper">
      <!-- Sidebar -->
        
      <?php require_once("include/sidebar.php"); ?>     
      
      <?php require_once("include/header.php"); ?>

      <div class="site-content">
        <!-- Content -->
        <div class="content-area py-1">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10">
                <h4>Location</h4>
                <ol class="breadcrumb no-bg mb-1">
                  <li class="breadcrumb-item"><a href="<?=base_url().'Home'?>">Home</a></li>
                  <li class="breadcrumb-item active">Location</li>
                </ol>
              </div>
              
              <div class="col-md-2"></div>
            </div>
            
            
            <div class="box box-block bg-white">
              
              <table id="location_tbl" class="table table-striped table-borderd table-hover">

                  <thead>
                    <tr>
                      <th style="width:10%;">Sr. No.</th>
                      <th style="width:20%;">Name</th>
                      <th style="width:20%;">Email</th>
                      <th style="width:20%;">Location Name</th>
                      <th style="width:10%;">Cover Image</th>
                      <th style="width:10%;">Status</th>
                      <th style="width:10%;">Action</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach ($locationList as $key => $value) {
                      ?>
                    <tr>
                      <td onclick="gotoRoutes('<?=$value->location_id?>')" style="cursor: pointer;"><?=($key+1);?></td>
                      <td onclick="gotoRoutes('<?=$value->location_id?>')" style="cursor: pointer;"><?=$value->fname.' '.$value->lname?></td>
                      <td onclick="gotoRoutes('<?=$value->location_id?>')" style="cursor: pointer;"><?=$value->email?></td>
                      <td onclick="gotoRoutes('<?=$value->location_id?>')" style="cursor: pointer;"><?=$value->location_name?></td>
                      <td onclick="gotoRoutes('<?=$value->location_id?>')" style="cursor: pointer;">
                      	<?php
                      	if ($value->cover_image != "") { ?>
                      		<img src="<?=$value->cover_image?>" height="70" width="70">	
                      	<?php
                      	}
                      	?>
                      </td>
                      <td>
                        <select <?=($value->is_admin_confirm == 1?"disabled":"")?> id="statusdd_<?=$value->location_id;?>" class="form-control" onchange="btnClk($(this).val(),'<?=$value->location_id;?>','<?=$value->user_id;?>')">
                          <option <?=($value->is_admin_confirm == 0?"selected":"")?> value="0">Pending</option>
                          <option <?=($value->is_admin_confirm == 1?"selected":"")?> value="1">Approve</option>
                        </select>
                      </td>
                      <td>
                        <div class="btn-group">
                          <a class="btn btn-primary" href="#" title="Edit" data-target="#edit_loc_form" data-toggle="modal" data-backdrop="static" data-keyboard="false" onclick="edit_loc('<?=$value->location_id?>')"><i class="fa fa-pencil"></i></a>

                          <a class="btn btn-danger" href="#" title="Delete" onclick="delete_location('<?=$value->location_id?>');"><i class="fa fa-trash"></i></a>
                        </div>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
            </div>            
          </div>
        </div>
        
      </div>

     
    </div>

<!-- edit Modal -->
  <div class="modal fade in" id="edit_loc_form" role="dialog">
    <div class="modal-dialog" id="edit_loc"> 
      
  </div>
</div>
<!-- edit Modal End -->


  <!-- javascripts -->
  <?php require_once("include/all_script.php"); ?>

  <script type="text/javascript">
    jQuery(document).ready( function () {

         // var dataTable = $('#location_tbl').DataTable({"autoWidth": false});
          /* Create an array with the values of all the select options in a column */
            $.fn.dataTable.ext.order['dom-select'] = function  ( settings, col )
            {
                return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
                    return $('select', td).val();
                } );
            }
             

            var table = $("#location_tbl").DataTable({
                autoWidth: false,
                "columns": [
                        null,
                        null,
                        null,
                        null,
                        null,
                        { "orderDataType": "dom-select" },
                        null
                    ]
                
            });

           

    });

    function gotoRoutes(location_id) {
      window.location.href="<?=base_url().'Location/RouteList/'?>"+location_id;
    }

    

    function btnClk(btnval,location_id,user_id) {
      if (confirm("Are you sure to change status?")) {
          $.ajax({
              url: '<?=base_url() . "Location/requestStatus"?>',
              type: "POST",
              data: {location_id: location_id,status:btnval,user_id:user_id},
              cache: false,
              success: function (res) {
                if (res == 1) {
                  alert("Success");
                  $("#statusdd_"+location_id).attr("disabled",true);
                  //window.location.href = "<?=current_url();?>";  
                }
                else
                {
                  alert("Something went Wrong");
                }
                
              }
          });
      }
    }

    function edit_loc(locId){   
       $.ajax({
         type:"post",
         url:'<?=base_url()."Location/editLocation/"?>'+locId,
         success: function(data){
           $("#edit_loc").html(data);
         }
       });
     }

     function delete_location(locId){   
      if (confirm('Do you want to remove this Location?')) {
        $.ajax({
         type:"post",
         url:'<?=base_url()."Location/deleteLocation/"?>'+locId,
         success: function(data){
          window.location.href='<?=current_url()?>';
         }
       });
      }
     }

</script>  

</body>

</html>
