
<?php require_once("include/head.php"); ?>

  <body class="fixed-sidebar fixed-header skin-default content-appear">
    <div class="wrapper">
      <!-- Sidebar -->
        
      <?php require_once("include/sidebar.php"); ?>     
      
      <?php require_once("include/header.php"); ?>

      <div class="site-content">
        <!-- Content -->
        <div class="content-area py-1">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10">
                <h4>Routes</h4>
                <ol class="breadcrumb no-bg mb-1">
                  <li class="breadcrumb-item"><a href="<?=base_url().'Home'?>">Home</a></li>
                  <li class="breadcrumb-item"><a href="<?=base_url().'Location'?>">Location</a></li>
                  <li class="breadcrumb-item active">Routes</li>
                </ol>
              </div>
              
              <div class="col-md-2"></div>
            </div>
            
            
            <div class="box box-block bg-white">
              
              <table id="routes_tbl" class="table table-striped table-borderd table-hover">

                  <thead>
                    <tr>
                      <th style="width:10%;">Sr. No.</th>
                      <th style="width:10%;">Name</th>
                      <th style="width:20%;">Email</th>
                      <th style="width:10%;">Location Name</th>
                      <th style="width:10%;">Route Name</th>
                      <th style="width:10%;">Grade Opinion</th>
                      <th style="width:10%;">Image</th>
                      <th style="width:10%;">Status</th>
                      <th style="width:10%;">Action</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach ($routeList as $key => $value) {
                      ?>
                    <tr>
                      <td><?=($key+1);?></td>
                      <td><?=$value->fname.' '.$value->lname?></td>
                      <td><?=$value->email?></td>
                      <td><?=$value->location_name?></td>
                      <td><?=$value->route_name?></td>
                      <td><?=$value->grade_opinion?></td>
                      <td>
                      	<?php
                      	if ($value->photo != "") { ?>
                      		<img src="<?=$value->photo?>" height="70" width="70">	
                      	<?php
                      	}
                      	?>
                      </td>
                      <td>
                        <select <?=($value->is_admin_confirm == 1?"disabled":"")?> id="statusdd_<?=$value->route_id;?>" class="form-control" onchange="btnClk($(this).val(),'<?=$value->route_id;?>','<?=$value->user_id;?>')">
                          <option <?=($value->is_admin_confirm == 0?"selected":"")?> value="0">Pending</option>
                          <option <?=($value->is_admin_confirm == 1?"selected":"")?> value="1">Approve</option>
                        </select>
                      </td>
                      <td>
                        <div class="btn-group">
                          <a class="btn btn-primary" href="#" title="Edit" data-target="#edit_route_form" data-toggle="modal" data-backdrop="static" data-keyboard="false" onclick="edit_route('<?=$value->route_id?>')"><i class="fa fa-pencil"></i></a>

                          <a class="btn btn-danger" href="#" title="Delete" onclick="delete_route('<?=$value->route_id?>');"><i class="fa fa-trash"></i></a>
                        </div>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
            </div>            
          </div>
        </div>
        
        
      </div>
      

    </div>


<!-- edit Modal -->
  <div class="modal fade in" id="edit_route_form" role="dialog">
    <div class="modal-dialog" id="edit_route"> 
      
  </div>
</div>
<!-- edit Modal End -->

  <!-- javascripts -->
  <?php require_once("include/all_script.php"); ?>

  <script type="text/javascript">
    jQuery(document).ready( function () {

          //var dataTable = $('#routes_tbl').DataTable({"autoWidth": false});
           /* Create an array with the values of all the select options in a column */
            $.fn.dataTable.ext.order['dom-select'] = function  ( settings, col )
            {
                return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
                    return $('select', td).val();
                } );
            }
             

            var table = $("#routes_tbl").DataTable({
                autoWidth: false,
                "columns": [
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        { "orderDataType": "dom-select" },
                        null
                    ]
                
            });

             

    });

    function btnClk(btnval,route_id,user_id) {
      if (confirm("Are you sure to change status?")) {
          $.ajax({
              url: '<?=base_url() . "Routes/requestStatus"?>',
              type: "POST",
              data: {route_id: route_id,status:btnval,user_id:user_id},
              cache: false,
              success: function (res) {
                if (res == 1) {
                  alert("Success");
                  $("#statusdd_"+route_id).attr("disabled",true);
                  //window.location.href = "<?=current_url();?>";  
                }
                else
                {
                  alert("Something went Wrong");
                }
                
              }
          });
      }
    }


      function edit_route(routeId){   
       $.ajax({
         type:"post",
         url:'<?=base_url()."Routes/editRoute/"?>'+routeId,
         success: function(data){
           $("#edit_route").html(data);
         }
       });
     }

     function delete_route(routeId){   
      if (confirm('Do you want to remove this Route?')) {
        $.ajax({
         type:"post",
         url:'<?=base_url()."Routes/deleteRoute/"?>'+routeId,
         success: function(data){
          window.location.href='<?=current_url()?>';
         }
       });
      }
     }

</script>  

</body>

</html>
