<!-- Preloader -->
			<div class="preloader"></div>
			<div class="site-sidebar">
				<div class="custom-scroll custom-scroll-light">
					<ul class="sidebar-menu">						
						
						<li class="<?php if($this->uri->segment(1)=='Home'){ echo 'active'; }?>">
							<a href="<?=base_url().'Home'?>" class="waves-effect  waves-light">
								<span class="s-icon"><i class="ti-anchor"></i></span>
								<span class="s-text">Dashboard</span>
							</a>
						</li>

						<li class="<?php if($this->uri->segment(1)=='User'){ echo 'active'; }?>">
							<a href="<?=base_url().'User'?>" class="waves-effect  waves-light">
								<span class="s-icon"><i class="ti-user"></i></span>
								<span class="s-text">User</span>
							</a>
						</li>

						<li class="<?php if($this->uri->segment(1)=='Location'){ echo 'active'; }?>">
							<a href="<?=base_url().'Location'?>" class="waves-effect  waves-light">
								<span class="s-icon"><i class="fa fa-map"></i></span>
								<span class="s-text">Location</span>
							</a>
						</li>

						<li class="<?php if($this->uri->segment(1)=='Vouchers'){ echo 'active'; }?>">
							<a href="<?=base_url().'Vouchers'?>" class="waves-effect  waves-light">
								<span class="s-icon"><i class="fa fa-gift"></i></span>
								<span class="s-text">Vouchers</span>
							</a>
						</li>

						<!-- <li class="<?php if($this->uri->segment(1)=='Routes'){ echo 'active'; }?>">
							<a href="<?=base_url().'Routes'?>" class="waves-effect  waves-light">
								<span class="s-icon"><i class="fa fa-map-marker"></i></span>
								<span class="s-text">Routes</span>
							</a>
						</li> -->
						
						
					</ul>
				</div>
			</div>