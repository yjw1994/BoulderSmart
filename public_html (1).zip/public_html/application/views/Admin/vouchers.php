
<?php require_once("include/head.php"); ?>

  <body class="fixed-sidebar fixed-header skin-default content-appear">
    <div class="wrapper">
      <!-- Sidebar -->
        
      <?php require_once("include/sidebar.php"); ?>     
      
      <?php require_once("include/header.php"); ?>

      <div class="site-content">
        <!-- Content -->
        <div class="content-area py-1">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-10">
                <h4>Vouchers</h4>
                <ol class="breadcrumb no-bg mb-1">
                  <li class="breadcrumb-item"><a href="<?=base_url().'Home'?>">Home</a></li>
                  <li class="breadcrumb-item active">Vouchers</li>
                </ol>
              </div>
              
              <div class="col-md-2">
                <button type="button" class="btn btn-primary"><a href="#" data-target="#add_voucher_form" data-toggle="modal" data-backdrop="static" data-keyboard="false" style="color: #FFF;">Add Voucher</a></button>
              </div>
            </div>
            
            
            <div class="box box-block bg-white">
              
              <table id="voucher_tbl" class="table table-striped table-borderd table-hover">

                  <thead>
                    <tr>
                      <th style="width:10%;">Sr. No.</th>
                      <th style="width:20%;">Name</th>
                      <th style="width:20%;">Discount</th>
                      <th style="width:15%;">Points</th>
                      <th style="width:15%;">Voucher Code</th>
                      <th style="width:10%;">Cover Image</th>
                      <th style="width:10%;">Action</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    foreach ($voucherList as $key => $value) {
                      ?>
                    <tr>
                      <td ><?=($key+1);?></td>
                      <td ><?=$value->voucher_name?></td>
                      <td ><?=$value->discount?></td>
                      <td ><?=$value->points?></td>
                      <td ><?=$value->voucher_code?></td>
                      <td >
                      	<?php
                      	if ($value->voucher_image != "") { ?>
                      		<img src="<?=$value->voucher_image?>" height="70" width="70">	
                      	<?php
                      	}
                      	?>
                      </td>
                      <td>
                        <div class="btn-group">
                          <a class="btn btn-primary" href="#" title="Edit" data-target="#edit_voucher_form" data-toggle="modal" data-backdrop="static" data-keyboard="false" onclick="edit_voucher('<?=$value->voucher_id?>')"><i class="fa fa-pencil"></i></a>

                          <a class="btn btn-danger" href="#" title="Delete" onclick="delete_voucher('<?=$value->voucher_id?>');"><i class="fa fa-trash"></i></a>
                        </div>
                      </td>
                    </tr>
                    <?php } ?>
                  </tbody>
                </table>
            </div>            
          </div>
        </div>
        
      </div>

      <!-- Add Modal -->
        <div class="modal fade in" id="add_voucher_form" role="dialog">
          <div class="modal-dialog modal-content" > 
            <form method="post" enctype="multipart/form-data">
              
              <div class="modal-header"> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">x</span>
                </button>
                <h4 class="modal-title">Add Voucher</h4>
              </div>
              <div class="modal-body">
                      
                       <div class="form-group">
                          <div class="row">
                          <div class="col-md-6 col-sm-6 col-xs-6 col-md-offset-5 col-sm-offset-4 col-xs-offset-4">
                             <label for="img_add">
                                <img id="imgUpload_add" src="<?=base_url()?>assets/images/defaultImg.png" alt="Cover Image" style="cursor: pointer; height: 100px; width: 100px;" />
                              </label>
                                <input id="img_add" type="file" accept="image/*" name="voucher_image" style="display:none;" onChange="return sendData_add()" required />
                              
                          </div>
                          <div class="clearfix"> </div>
                           </div>
                        </div>

                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <input type="text" class="form-control" placeholder="Voucher Name" name="voucher_name" value="" required="required" />
                            </div>
                            <div class="clearfix"> </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <div class="row">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                              <input type="text" class="form-control" placeholder="Voucher Code" name="voucher_code" value="" required="required" />
                            </div>
                            <div class="clearfix"> </div>
                          </div>
                        </div>

                        
                         <div class="form-group">
                          <div class="row">
                            <div class="col-md-6 col-sm-12 col-xs-12">
                              <input type="text" class="form-control numbers" placeholder="Points" name="points" required="required"  value="" />
                            </div>

                             <div class="col-md-6 col-sm-12 col-xs-12">
                              <input type="text" class="form-control numbers" min="1" max="100" placeholder="Discount" name="discount" required="required" value="" />
                            </div>
                            <div class="clearfix"> </div>
                          </div>
                        </div>
                    
              </div>
              <div class="modal-footer">
                <input type="submit" name="add_voucher" class="btn btn-primary" value="Add Voucher"/>
              </div>  
            </form>
        </div>
      </div>
      <!-- edit Modal End -->
     
    </div>

<!-- edit Modal -->
  <div class="modal fade in" id="edit_voucher_form" role="dialog">
    <div class="modal-dialog" id="edit_voucher"> 
      
  </div>
</div>
<!-- edit Modal End -->


  <!-- javascripts -->
  <?php require_once("include/all_script.php"); ?>

  <script type="text/javascript">
    jQuery(document).ready( function () {

          var dataTable = $('#voucher_tbl').DataTable({"autoWidth": false});

    });



    function edit_voucher(locId){   
       $.ajax({
         type:"post",
         url:'<?=base_url()."Vouchers/editVoucher/"?>'+locId,
         success: function(data){
           $("#edit_voucher").html(data);
         }
       });
     }

     function delete_voucher(locId){   
      if (confirm('Do you want to remove this Vouchers?')) {
        $.ajax({
         type:"post",
         url:'<?=base_url()."Vouchers/deleteVoucher/"?>'+locId,
         success: function(data){
          window.location.href='<?=current_url()?>';
         }
       });
      }
     }

</script>  

</body>

</html>
