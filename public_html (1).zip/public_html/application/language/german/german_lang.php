<?php
   $lang['msg'] = "CodeIgniter Internationalisierung Beispiel.";
?>