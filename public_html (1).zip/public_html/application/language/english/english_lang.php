<?php
   $lang['msg'] = "CodeIgniter Internationalization example.";
?>