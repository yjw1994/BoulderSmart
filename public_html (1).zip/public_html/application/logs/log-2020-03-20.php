<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-20 14:17:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-20 14:17:43 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-20 14:17:51 --> 404 Page Not Found: A/index
