<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-16 13:48:00 --> 404 Page Not Found: Blog/index
ERROR - 2020-03-16 14:22:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-16 14:22:12 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-16 14:22:15 --> 404 Page Not Found: A/index
ERROR - 2020-03-16 14:22:23 --> 404 Page Not Found: A/index
