<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-28 15:25:45 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-28 15:25:46 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-28 15:25:49 --> 404 Page Not Found: A/index
ERROR - 2020-02-28 15:25:53 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-28 15:25:54 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-28 15:25:56 --> 404 Page Not Found: A/index
ERROR - 2020-02-28 15:25:59 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-28 15:26:04 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
