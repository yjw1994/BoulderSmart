<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-12 13:30:53 --> 404 Page Not Found: Blog/index
ERROR - 2020-04-12 14:20:35 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-12 14:20:37 --> 404 Page Not Found: A/index
ERROR - 2020-04-12 14:20:42 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-12 14:20:43 --> 404 Page Not Found: A/index
ERROR - 2020-04-12 14:20:44 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-12 14:20:44 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-12 14:20:47 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-12 14:20:48 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-12 14:20:49 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-12 15:02:18 --> 404 Page Not Found: Robotstxt/index
