<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-13 14:05:20 --> 404 Page Not Found: Admin/index
ERROR - 2020-03-13 14:20:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-13 14:20:13 --> 404 Page Not Found: A/index
ERROR - 2020-03-13 14:20:20 --> 404 Page Not Found: A/index
ERROR - 2020-03-13 14:20:23 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
