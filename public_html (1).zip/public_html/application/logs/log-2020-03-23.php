<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-23 06:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-23 14:24:20 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-23 14:24:22 --> 404 Page Not Found: A/index
ERROR - 2020-03-23 14:24:25 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-23 14:24:30 --> 404 Page Not Found: A/index
