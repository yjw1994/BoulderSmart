<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-23 15:18:15 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-23 15:18:23 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-23 15:18:26 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-23 15:18:27 --> 404 Page Not Found: A/index
ERROR - 2020-02-23 15:18:28 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-23 15:18:28 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-02-23 15:18:32 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-23 15:18:33 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
