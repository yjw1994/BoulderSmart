<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-16 04:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-02-16 15:26:37 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-16 15:26:39 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-16 15:26:45 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-16 15:26:47 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-16 15:26:48 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-02-16 15:26:50 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-16 15:26:55 --> 404 Page Not Found: A/index
