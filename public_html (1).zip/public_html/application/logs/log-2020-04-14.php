<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-14 14:16:43 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-14 14:16:46 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-14 14:16:50 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-14 14:16:52 --> 404 Page Not Found: A/index
ERROR - 2020-04-14 14:16:57 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
