<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-20 12:33:09 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 166
ERROR - 2020-01-20 12:33:34 --> Query error: Unknown column 'is_manual_email' in 'field list' - Invalid query: INSERT INTO `user_master` (`fname`, `lname`, `email`, `pass`, `is_fb`, `fb_id`, `device_type`, `device_token`, `created_date`, `is_confirm`, `is_manual_email`) VALUES ('Mayur', 'Patel', 'mayur.kmphasis@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', '', '2020-01-20 12:33:34', 0, 0)
ERROR - 2020-01-20 12:34:08 --> Query error: Unknown column 'is_manual_email' in 'field list' - Invalid query: INSERT INTO `user_master` (`fname`, `lname`, `email`, `pass`, `is_fb`, `fb_id`, `device_type`, `device_token`, `created_date`, `is_confirm`, `is_manual_email`) VALUES ('Mayur', 'Patel', 'mayur.kmphasis@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '0', '', '', '', '2020-01-20 12:34:08', 0, '0')
ERROR - 2020-01-20 13:10:14 --> 404 Page Not Found: Api/User/cover_image
ERROR - 2020-01-20 13:55:25 --> Severity: error --> Exception: syntax error, unexpected ''route_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 923
ERROR - 2020-01-20 13:55:33 --> Severity: error --> Exception: syntax error, unexpected ''route_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ']' C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 923
ERROR - 2020-01-20 14:30:48 --> Query error: Unknown column 'ratting' in 'field list' - Invalid query: SELECT `route_id`, `route_name`, `grade_opinion`, `ratting`, `photo`
FROM `route_master`
WHERE `location_id` = '1'
ERROR - 2020-01-20 16:52:02 --> Severity: error --> Exception: syntax error, unexpected '",photo,"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\BoulderSmart\application\controllers\Api\User.php 1048
ERROR - 2020-01-20 16:54:23 --> Query error: Unknown column 'http://localhost/BoulderSmart/assets/cover_image/.cover_image' in 'field list' - Invalid query: SELECT *, if(cover_image !='', `http://localhost/BoulderSmart/assets/cover_image/`.`cover_image`, '') as cover_image
FROM `location_master`
WHERE `user_id` = '1'
ERROR - 2020-01-20 16:55:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`cover_image`, '') as cover_image
FROM `location_master`
WHERE `user_id` = '1'' at line 1 - Invalid query: SELECT *, if(cover_image !='', `http://localhost/BoulderSmart/assets/cover_image/` `cover_image`, '') as cover_image
FROM `location_master`
WHERE `user_id` = '1'
ERROR - 2020-01-20 16:59:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '://localhost/BoulderSmart/assets/cover_image/, cover_image) as cover_image, '')
' at line 1 - Invalid query: SELECT *, IF(cover_image != '', concat(http://localhost/BoulderSmart/assets/cover_image/, cover_image) as cover_image, '')
FROM `location_master`
WHERE `user_id` = '1'
ERROR - 2020-01-20 16:59:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '://localhost/BoulderSmart/assets/cover_image/, cover_image), '') as cover_image
' at line 1 - Invalid query: SELECT *, IF(cover_image != '', concat(http://localhost/BoulderSmart/assets/cover_image/, cover_image), '') as cover_image
FROM `location_master`
WHERE `user_id` = '1'
ERROR - 2020-01-20 17:00:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.'assets/cover_image/', cover_image), '') as cover_image
FROM `location_master`
' at line 1 - Invalid query: SELECT *, IF(cover_image != '', concat(base_url().'assets/cover_image/', cover_image), '') as cover_image
FROM `location_master`
WHERE `user_id` = '1'
