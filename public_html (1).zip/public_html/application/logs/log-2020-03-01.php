<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-01 13:30:38 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2020-03-01 15:19:14 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-01 15:19:15 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-01 15:19:18 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-03-01 15:19:22 --> 404 Page Not Found: A/index
ERROR - 2020-03-01 15:19:23 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-01 15:19:25 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-01 15:19:26 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-03-01 15:19:29 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-03-01 15:19:31 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-01 15:36:48 --> 404 Page Not Found: Wp/wp-admin
