<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-04 15:20:22 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-04 15:20:22 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-04 15:20:27 --> 404 Page Not Found: Login/.http:
ERROR - 2020-03-04 15:20:33 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-03-04 15:20:34 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-03-04 15:20:34 --> 404 Page Not Found: Login/.http:
