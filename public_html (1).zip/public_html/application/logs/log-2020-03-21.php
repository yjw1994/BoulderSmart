<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-21 05:26:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-03-21 14:24:53 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-21 14:24:54 --> 404 Page Not Found: A/index
ERROR - 2020-03-21 14:24:55 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-21 14:25:02 --> 404 Page Not Found: A/index
