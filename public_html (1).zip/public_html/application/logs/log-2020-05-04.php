<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-04 08:36:56 --> 404 Page Not Found: Robotstxt/index
