<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-17 14:26:34 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-17 14:26:35 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-17 14:26:41 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-17 14:26:43 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-17 14:26:43 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-17 14:26:52 --> 404 Page Not Found: CPanel_magic_revision_1584636102/unprotected
ERROR - 2020-04-17 14:26:52 --> 404 Page Not Found: A/index
