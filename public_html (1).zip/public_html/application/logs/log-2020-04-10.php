<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-10 14:20:54 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-10 14:20:54 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-10 14:20:55 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-10 14:21:05 --> 404 Page Not Found: A/index
ERROR - 2020-04-10 14:21:06 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-10 14:21:07 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-10 14:21:08 --> 404 Page Not Found: Login/.http:
