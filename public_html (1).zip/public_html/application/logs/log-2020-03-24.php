<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-24 12:45:46 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2020-03-24 12:45:47 --> 404 Page Not Found: Ftpconfig/index
ERROR - 2020-03-24 12:45:48 --> 404 Page Not Found: Remote-syncjson/index
ERROR - 2020-03-24 12:45:48 --> 404 Page Not Found: Vscode/ftp-sync.json
ERROR - 2020-03-24 12:45:49 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2020-03-24 12:45:50 --> 404 Page Not Found: Deployment-configjson/index
ERROR - 2020-03-24 12:45:51 --> 404 Page Not Found: Ftpsyncsettings/index
ERROR - 2020-03-24 14:20:07 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-24 14:20:07 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-24 14:20:14 --> 404 Page Not Found: A/index
