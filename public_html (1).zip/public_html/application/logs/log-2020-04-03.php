<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-03 14:23:10 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-04-03 14:23:11 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-04-03 14:23:12 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-03 14:23:20 --> 404 Page Not Found: Login/.http:
ERROR - 2020-04-03 14:23:22 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
ERROR - 2020-04-03 14:23:23 --> 404 Page Not Found: A/index
ERROR - 2020-04-03 14:23:24 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-04-03 14:23:26 --> 404 Page Not Found: CPanel_magic_revision_1582811100/unprotected
