<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-05 15:22:11 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-02-05 15:22:12 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-02-05 15:22:19 --> 404 Page Not Found: A/index
ERROR - 2020-02-05 15:22:20 --> 404 Page Not Found: Login/.http:
ERROR - 2020-02-05 15:22:29 --> 404 Page Not Found: CPanel_magic_revision_1579116936/unprotected
ERROR - 2020-02-05 15:22:30 --> 404 Page Not Found: CPanel_magic_revision_1386192030/unprotected
ERROR - 2020-02-05 16:49:22 --> 404 Page Not Found: Wp-admin/index
ERROR - 2020-02-05 16:50:08 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-02-05 16:50:40 --> 404 Page Not Found: Admin/index
ERROR - 2020-02-05 17:13:07 --> 404 Page Not Found: Wp-admin/index
ERROR - 2020-02-05 17:13:47 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-02-05 17:14:21 --> 404 Page Not Found: Admin/index
ERROR - 2020-02-05 17:30:26 --> 404 Page Not Found: Wp-admin/index
ERROR - 2020-02-05 17:33:56 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-02-05 17:36:17 --> 404 Page Not Found: Admin/index
ERROR - 2020-02-05 17:49:21 --> 404 Page Not Found: Wp-admin/index
ERROR - 2020-02-05 17:50:06 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-02-05 17:50:52 --> 404 Page Not Found: Admin/index
ERROR - 2020-02-05 18:05:10 --> 404 Page Not Found: Wp-admin/index
ERROR - 2020-02-05 18:05:46 --> 404 Page Not Found: Adminphp/index
ERROR - 2020-02-05 18:06:19 --> 404 Page Not Found: Admin/index
