<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-21 09:39:51 --> 404 Page Not Found: Lang/index
