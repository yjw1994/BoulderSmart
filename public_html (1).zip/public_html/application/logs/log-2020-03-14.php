<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-14 12:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-14 13:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2020-03-14 13:35:25 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2020-03-14 13:35:27 --> 404 Page Not Found: Adstxt/index
ERROR - 2020-03-14 14:22:32 --> 404 Page Not Found: Th1s_1s_a_4o4html/index
ERROR - 2020-03-14 14:22:33 --> 404 Page Not Found: Http:/www.bouldersmartapplication.space
ERROR - 2020-03-14 14:22:42 --> 404 Page Not Found: A/index
