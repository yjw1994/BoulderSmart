<?php
ob_start();
error_reporting(0);
class User extends CI_Controller{
	public function __construct()
    {
    	parent::__construct();
    }
	
	public function index()
	{
		if($this->session->userdata('sess_id'))
		{
		 	
		 	
		 	$data['userList']=$this->model->select_ser("user_master",array("is_confirm"=>1,"is_delete"=>0));

		 	$this->load->view('Admin/user',$data);
		}
		else
		{
			redirect(base_url());	
		}	
	}

	

	public function requestStatus()
	{
		$user_id = $this->input->post("user_id");
		$status = $this->input->post("status");
		$scExit = 0;
		if ($status == "Paid") {
			$this->model->update("payment_master",array("status"=>"Success"),array("user_id"=>$user_id));
			$scExit = 1;
		}
		echo $scExit;
	}



  

}