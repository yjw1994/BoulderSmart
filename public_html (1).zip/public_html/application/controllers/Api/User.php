<?php
header('Content-type: application/json; charset=utf-8');
require_once("Comman_controller.php");
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(0);
//ob_start();

class User extends CI_Controller {
  public function __construct()
  {
    parent::__construct();
  }     

  public function test($value='')
  {
    echo "test";
  }

  
  public function signUp()
   {
    comman_controller::varifyMethod("POST");
    extract($_POST);
    
    $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];  
    //$profile=$_FILES['profile']['name']; 

    comman_controller::requiredValidation([
      'key' => $key
    ]);

    if($this->model->checkKeyExist($key)==0){
      return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
    }
    
    $chkfb=$this->model->sel_row("user_master",array("is_delete"=>0,"fb_id"=>$fb_id));
    
    if(($fb_id!="" || $fb_id!=null) && count($chkfb)>0){
      if($chkfb->email!="" || $chkfb->email!=null){
        $email_data['email'] = $chkfb->email; 
            $data1['data'] = $email_data; 
              
        return  comman_controller::successResponse($data1,0,'Email already exist','False');
      }
      else{
        return comman_controller::responseMessage(0, "Please enter email", "False");
      }
    }
    else{
      comman_controller::requiredValidation([
        'email' => $email
      ]); 
    }

    if($is_fb==0){
      comman_controller::requiredValidation([
        'fname'=>$fname,
        'lname'=>$lname,
        'email'=>$email,
        'password'=>$password
      ]);
    }

  
   if($is_fb==1){
      comman_controller::requiredValidation([
        'fb_id'=>$fb_id,
        'fname'=>$fname,
        'lname'=>$lname,
        'password'=>$password
      ]);
    }
    
  
    
    $chkmail=$this->model->sel_row("user_master",array("is_delete"=>0,"email"=>$email));
   
    if(count($chkmail)>0){
      if($chkmail->is_fb==1){
        $sUser="facebook user";
      }
      else{
        $sUser="normal user";
      }
      
      return comman_controller::responseMessage(0, "This email has already been registered as a $sUser. Sign into your existing account, or register with a different email.", "False");
    }
    
    else{
      
     
      

      if($is_fb==""){
        $is_fb="";
      }
 
      if($fb_id==""){
        $fb_id="";
      }
      
     

      if($device_type==""){
        $device_type="";
      }

      if($device_token==""){
        $device_token="";
      } 
     
        /*if($profile!="" || $profile!=NULL){         
          $ext= pathinfo($profile, PATHINFO_EXTENSION);
          $newname=uniqid()."_profile_".time().".".$ext;
          $tmpname=$_FILES['profile']['tmp_name'];
          move_uploaded_file($tmpname, "assets/profile/".$newname);
        }
        else{
          $newname="";
        }*/
       
      $email1=strtolower($email);
      
      if($is_manual_email==""){
        $is_manual_email=0;
      }
      if($is_fb==1 && $is_manual_email==0){
        $isConfirm=1;
        $respMsg='Registration has been completed successfully.';
        $respCode=1;
      }else{
        $isConfirm=0;
        $respMsg="Registration has been completed successfully. Please click on the confirmation link sent to your email to activate this account.\n Please check spam folder also for verification mail.";
        $respCode=2;
      }

      $insdata=array("fname"=>$fname,"lname"=>$lname,"email"=>$email1,"pass"=>$password,"is_fb"=>$is_fb,"fb_id"=>$fb_id,"device_type"=>$device_type,"device_token"=>$device_token,"created_date"=>cur_date_time,"is_confirm"=>$isConfirm,"is_manual_email"=>$is_manual_email);

      $generateToken = comman_controller::generateToken();

      $insid=$this->model->insert("user_master",$insdata);
     
      $this->model->insert('key_token_master',array("key"=>$key,"token"=>$generateToken,"cdate"=>cur_date_time));

      $user_detail=$this->model->sel_row("user_master",array("is_delete"=>0,"user_id"=>$insid));
      
      if(count($user_detail)>0){
        $user_data=$this->getUserDtl($user_detail,$generateToken);
        $data['data'] = $user_data; 
        
        if(($email!='' && $is_fb==1 && $is_manual_email==1) || ($email!='' && $is_fb==0)){
          $this->mailUser($email,$fname);
        } 
        return comman_controller::successResponse($data,$respCode,$respMsg,'True');
               
      }
      else{
        return comman_controller::responseMessage(0, "Something went wrong while Registration, please try again.", "False");
      }
    } 
    
  }

  public function getUserDtl($user_detail,$generateToken)
  {
            
    /*if($user_detail->profile!=""){
      $user_detail->profile = server_url."assets/profile/".$user_detail->profile;
    }
    else{
       $user_detail->profile = "";
    }*/
    unset($user_detail->pass);

    $user_detail->token = $generateToken; 

    return $user_detail;
  }
  
   public function resendConfirm(){
        comman_controller::varifyMethod("POST");
        
        extract($_POST);
        
        $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
        $email=$this->input->post('email');
        
        $fb_id=$this->input->post('fb_id');

        if ($fb_id != "" && $fb_id != NULL) {
          $chkfbMail=$this->model->sel_row("user_master",array("is_delete"=>0,"fb_id"=>$fb_id,"is_fb"=>1));
          $email = $chkfbMail->email;
        }

        comman_controller::requiredValidation([
            'key'=>$key,
            'email' => $email            
         ]);


        if($this->model->checkKeyExist($key)==0){
          return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
        }
        
       $chkmail=$this->model->sel_row("user_master",array("is_delete"=>0,"email"=>$email));    
        
        
        if(count($chkmail)==0){
          return comman_controller::responseMessage(0, "Please enter correct email. This email is not registered with us.", "False");
        }
        else if(count($chkmail)>0 && $chkmail->is_confirm==1){
          return comman_controller::responseMessage(0, "This account is already confirmed.", "False");
        }    
        else if($chkmail->email==$email)
        { 
          $this->mailUser($email,$chkmail->name); 
          return comman_controller::responseMessage(1, "Confirmation link is sent to your registered email address.\nPlease check spam folder also for verification mail.", "True");
        }
       
        else{
          return comman_controller::responseMessage(0, "This email is not registered with us. Please register with different email.", "False");
        }

  }



   public function mailUser($email,$name){     

             $encEmail=base64_encode($email);

             $link=server_url."Core/user.php?email=$encEmail";

             $messageUser= '
                 <center>
                <div style="background: #EEEEEE" ><br/>
                  <div  style="background-image: url('.email_header.');background-position: center;height:100%;max-width:600px;background-size: 100% 100%;">
                    <div style="padding-top: 15%;padding-bottom: 5%;">
                      <img width="90" height="90" src="'.email_logo.'"/><br/>
                      <h2>Welcome to '.server_name.', '.$name.' </h2>
                      <br/>
                       <span style="font-size: 18px;">

                    Thank you for creating '.server_name.' account.
                    <br/></span>
                    </div>
                  </div>
                  <div style="background: #fff;width: 600px;margin-left:5%;margin-right:5%;">

                    <span style="font-size: 18px;padding-left:10px;padding-right:10px;display:inline-grid;">

                     To access your account, confirm your email verification process <a href="'.$link.'">click here</a> to confirm your email.
                   </span>
                                <br/><br/>
                                <span style="font-size: 18px;">Sincerely yours,<br/>
                                  '.server_name.' Team
                                </span>
                  </div>
                  <img style="width: 680px;" src="'.email_footer.'"/>
                </div>
            </center>';
             
           comman_controller::sendMail($email, "Confirmation email from ".server_name, $messageUser);
           // comman_controller::sendMailSMTP($email, "Confirmation email from ".server_name, $messageUser);
  } 
  
  public function isRegister()
  {
    comman_controller::varifyMethod("POST");
    extract($_POST);
    
    $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];  
    
    comman_controller::requiredValidation([
      'key' => $key
    ]);

    if(($is_fb=="" || $is_fb==NULL) && ($email=="" || $email==NULL)){
       return comman_controller::responseMessage(0, "Please enter is_fb or email.", "False");
    }

    else if($is_fb==1){
      comman_controller::requiredValidation([
            'fb_id' => $fb_id
      ]);
    }
    
    if($this->model->checkKeyExist($key)==0){
      return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
    }
      
      if($email!=""){
        $user_detail=$this->model->sel_row("user_master",array("is_delete"=>0,"email"=>$email));
      }
       else {
        if($is_fb==1){
          $user_detail=$this->model->sel_row("user_master",array("is_delete"=>0,"fb_id"=>$fb_id));
        
        }

      }

        if(count($user_detail)>0 && $user_detail->is_confirm==0){
          return comman_controller::responseMessage(2, "Please click on the confirmation link sent to your email to activate this account.", "False");
        }
        else if(count($user_detail)>0 && $user_detail->is_fb==0 ){
          comman_controller::responseMessage(4,"$user_detail->email is registered as a normal user. Please login as a normal user or try with different email id.",'True');
        }
        else if(count($user_detail)>0){  
          $userData=$this->getReguserData($device_type,$device_token,$user_detail);

          $data['data'] = $userData; 
                  
          comman_controller::successResponse($data, 1,'Login successful.','True');
        }
        else{
          return comman_controller::responseMessage(3, "This user is not registered with us.", "False");
        }             
  }
 

 
  public function getReguserData($device_type,$device_token,$user_detail)
  {
          if($device_type==""){
            $device_type="";
          }

          if($device_token==""){
            $device_token="";
          }

          $upddata=array("device_type"=>$device_type,"device_token"=>$device_token,"updated_date"=>cur_date_time);
          $this->model->update("user_master",$upddata,array("user_id"=>$user_detail->user_id));

            
            /*if($user_detail->profile!=""){
              $user_detail->profile = server_url."assets/profile/".$user_detail->profile;
            }
            else{
               $user_detail->profile = "";
            }*/
            unset($user_detail->pass);
            $tokenRet=$this->model->querydatar("select * from key_token_master order by rand()");
            $user_detail->token = $tokenRet->token;
            return $user_detail; 
  }
  
  
 public function login(){

    try{
    comman_controller::varifyMethod('POST');
    extract($_POST);
    $key=empty($_SERVER['HTTP_KEY']) ? '' :$_SERVER['HTTP_KEY'];

    comman_controller::requiredValidation([
        'Key'=>$key,
        'email'=>$email,
        'password'=>$password
    ]);

        if($this->model->checkKeyExist($key)==0){
            return comman_controller::responseMessage(0,"Please enter correct key, eneterd key doesn’t match with provided key.","False");
            }
        else{

            $user_detail=$this->model->querydatar("select * from user_master where email='$email' and binary pass='$password' and is_confirm=1 and is_delete=0");

            $chkEmail=$this->model->sel_row("user_master",array("is_delete"=>0,"email"=>$email));
            
            if(count($chkEmail)==0){
              return comman_controller::responseMessage(0, "Invalid email", "False");
            }
            if(count($chkEmail)>0 && $chkEmail->is_confirm==0){
                return comman_controller::responseMessage(2, "Please click on the confirmation link sent to your email to activate this account.", "False");
            }
            else if(count($chkEmail)>0 && $chkEmail->is_google==1){
               comman_controller::successResponse($data, 4,"$chkEmail->email is registered as a Google user. Please login as a Google user or try with different email id.",'True');
            }
            else if(count($chkEmail)>0 && $chkEmail->is_fb==1){
               comman_controller::successResponse($data, 4,"$chkEmail->email is registered as a Facebook user. Please login as a Facebook user or try with different email id.",'True');
            }
            else if (count($user_detail)>0) {
              $user_data=$this->getReguserData($device_type,$device_token,$user_detail);     
           
              $data['data'] = $user_data; 
                      
              comman_controller::successResponse($data, 1,'Login successful','True');      
            }
          
          else{
            return comman_controller::responseMessage(0, "Invalid password", "False");
          }

        }  
    }  
    catch (Exception $e) {
         return comman_controller::responseMessage(0, "Something went wrong while login, please try again.", "False");
    }
 } 
  

  public function forgotPassword()
    { 
        comman_controller::varifyMethod("POST");
        
        extract($_POST);
        
        $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
       
        comman_controller::requiredValidation([
            'key'=>$key,
            'email' => $email            
         ]);

        if($this->model->checkKeyExist($key)==0){
          return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
        }
       
        $chkEmail=$this->model->sel_row("user_master",array("is_delete"=>0,"email"=>$email));
        $ucode = comman_controller::generateRandomCode();


        if(count($chkEmail)==0){
            return comman_controller::responseMessage(0, "Please enter correct email. This email is not registered with us.", "False");
        }
        else if($chkEmail->is_google==1){
          return comman_controller::responseMessage(2, "Unable to send link. You signed up through Google. Please sign in with Google to access your account.", "False");
        }
        else if($chkEmail->is_fb==1){
          return comman_controller::responseMessage(2, "You are login with facebook, Sorry you can't do it.", "False");
        }  
        else if(count($chkEmail)>0 && $chkEmail->is_confirm==0){
          return comman_controller::responseMessage(2, "Please click on the confirmation link sent to your email to activate this account.", "False");
        }    
        else if(count($chkEmail)>0)
        { 
          $this->model->update("user_master",array("ucode"=>$ucode),array("email"=>$email));
          $this->mailForForgotPassword($email,$chkEmail->name,$ucode); 
          return comman_controller::responseMessage(1, "Reset password link has been sent to your registered email address.", "True");
        }
        else{
          return comman_controller::responseMessage(0, "Something went wrong", "False");
        }
    }

    function mailForForgotPassword($email,$name,$ucode)
    {
        $encEmail=base64_encode($email);

        $link=server_url."Core/resetPassword.php?email=$encEmail";

        $message = '<center>
                <div style="background: #EEEEEE" ><br/>
                  <div  style="background-image: url('.email_header.');background-position: center;max-width:600px;background-size: 100% 100%;">
                    <div style="padding-top: 15%;padding-bottom: 0%;">
                      <img width="90" height="90" src="'.email_logo.'"/><br/>
                      <h2>Hi '.$name.',</h2>
                      <br/>
                       <span style="font-size: 18px;text-align:center;padding-left:10px;padding-right:10px;display:inline-grid;">

                        We\'ve received a request to reset your password. If you didn\'t make the request, just ignore this email.
                    </span>
                    </div>
                  </div>
                  <div style="background: #fff;width: 600px;margin-left:5%;margin-right:5%;">

                    <span style="font-size: 18px;text-align:center;padding-left:10px;padding-right:10px;display:inline-grid;">
                    <a href="' . $link . '"> Click here to change your password.</a><br/>
                     If you have any questions or trouble logging on please contact an app administrator.
                   </span>
                                <br/><br/>
                                <span style="font-size: 18px;">Sincerely yours,<br/>
                                  '.server_name.' Team
                                </span>
                  </div>
                  <img style="width: 680px;" src="'.email_footer.'"/>
                </div>
            </center>';
           
      return comman_controller::sendMail($email, "Forgot your password?", $message);
     // return comman_controller::sendMailSMTP($email, "Forgot your password?", $message);
      

    }
    
   
    public function updateProfile()
    {
    
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $profile=$_FILES['profile']['name'];
            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'fname' => $fname,
                'lname' => $lname,
                'email'=>$email
             ]);

        if($this->model->checkKeyExist($key)==0){
          return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
        }
        else if($this->model->checkKeyTokenExist($key,$token)==0){
            return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
        }            

            $userdtl=$this->model->sel_row('user_master',array("user_id"=>$user_id,"is_confirm"=>1,"is_delete"=>0));  
            
             if(count($userdtl)>0){
                    /*if($profile!="" || $profile!=NULL){         
                      $ext= pathinfo($profile, PATHINFO_EXTENSION);
                      $newname=uniqid()."_profile_".time().".".$ext;
                      $tmpname=$_FILES['profile']['tmp_name'];
                      move_uploaded_file($tmpname, "assets/profile/".$newname);
                      
                    }
                    else{
                      $newname=$userdtl->profile;
                    }*/ 
                    
                    if($email=="" || $email==NULL){
                        $email=$userdtl->email;
                    }
      
                    $upddata=array("fname"=>$fname,"lname"=>$lname,"email"=>$email,"updated_date"=>cur_date_time);
                    
                    $this->model->update("user_master",$upddata,array("user_id"=>$user_id));
                  
                    $user_detail=$this->model->sel_row("user_master",array("is_delete"=>0,"user_id"=>$user_id));

                    if(count($user_detail)>0){
                      $tokenRet=$this->model->querydatar("select * from key_token_master order by rand()");
                      $user_data=$this->getUserDtl($user_detail,$tokenRet->token);                       
                      $data['data'] = $user_data; 
                      comman_controller::successResponse($data, 1,'Profile has been updated successfully','True');
                    }
                    else{
                        return comman_controller::responseMessage(0, "Something went wrong while update rofile, please try again.", "False");
                    }
            }
            else{
                return comman_controller::responseMessage(0, "Unable to update profile because of Invalid user_id or account not confirm.", "False");
            }    
        }
   
    catch (Exception $e) {
        return comman_controller::responseMessage(0, "Something went wrong while update profile, please try again.", "False");
    }  
        
  }
    
    public function changePassword()
    { 
        comman_controller::varifyMethod("POST");
        
        extract($_POST);
        
        $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
        $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
        
        comman_controller::requiredValidation([
            'key' => $key,
            'token'=>$token,
            'user_id'=>$user_id,
            'old_password'=>$old_password,
            'new_password' => $new_password 
         ]);
        
        if($this->model->checkKeyExist($key)==0){
          return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
        }
        else if($this->model->checkKeyTokenExist($key,$token)==0){
          return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
        }

        $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
        if($count_user>0){
          $userdtl=$this->model->sel_row('user_master',array("user_id"=>$user_id));
          if($userdtl->pass==$old_password){
            if($userdtl->pass==$new_password){
              return comman_controller::responseMessage(0, "Your New password is same as old password. Please use different new password.", "False"); 
            }else{

              $this->model->update("user_master",array("pass"=>$new_password),array("user_id"=>$user_id));
            
             return comman_controller::responseMessage(1, "Your password changed successfully", "True");
           }
          }
          else{
            return comman_controller::responseMessage(0, "Your old password is incorrect", "False"); 
          }
         
        }
        else{
          return comman_controller::responseMessage(0, "Unable to change password because of Invalid user_id.", "False");
        }
            
        
    } 
  
  public function contactUs()
  { 
        comman_controller::varifyMethod("POST");
        
        extract($_POST);
        
        $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
        $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
        
        $name=$this->input->post('name');
        $email=$this->input->post('email');
        $subject=$this->input->post('subject');
        $message=$this->input->post('message');

        comman_controller::requiredValidation([
            'key' => $key,
            'token'=>$token,
            'name'=>$name,
            'email' => $email,
            'subject'=>$subject,
            'message'=>$message            
         ]);
        
        if($this->model->checkKeyExist($key)==0){
          return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
        }

        else if($this->model->checkKeyTokenExist($key,$token)==0){
           return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
        }
        
        $this->mailcontactus($name,$email,$subject,$message); 
       
        return comman_controller::responseMessage(1, "Thank you for contacting ".server_name .". We will get back to you shortly.", "True");
    }

    public function mailcontactus($name,$email,$subject,$message)
    {
        $message_body = '<center>
                <div style="background: #EEEEEE" ><br/>
                  <div  style="background-image: url('.email_header.');background-position: center;height: 100%;max-width:600px;background-size: 100% 100%;">
                    <div style="padding-top: 15%;padding-bottom: 5%;">
                      <img width="90" height="90" src="'.email_logo.'"/><br/>
                      <h2>User Information</h2>
                    </div>
                  </div>
                  <div style="background: #fff;width: 600px;margin-left:5%;margin-right:5%;">
                    <span style="text-align:center;font-size: 18px;text-align:center;padding-left:10px;padding-right:10px;">
                    Name : <b>' . $name . '</b> <br>
                    Email : <b>' . $email . '</b> <br>
                    subject : <b>' . $subject . '</b> <br>
                    Message  :  <b>' . $message . '</b>
                   </span>
                                <br/><br/>
                                <span style="font-size: 18px;">Sincerely yours,<br/>
                                  '.server_name.' Team
                                </span>
                  </div>
                  <img style="width: 680px;" src="'.email_footer.'"/>
                </div>
            </center>';

      comman_controller::sendMail(client_email, "Contact Us email from ".server_name,$message_body);
      
     // comman_controller::sendMailSMTP(client_email, "Contact Us email from ".server_name,$message_body);
    }
    
   

    public function logOut()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
           
            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id                          
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                    
              $this->model->update("user_master",array("device_type"=>"","device_token"=>"","updated_date"=>cur_date_time),array("user_id"=>$user_id));
              return comman_controller::responseMessage(1,'LogOut successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Unable to logout because of Invalid user_id.", "False");
            }    
        } 
    catch (Exception $e) {
        return comman_controller::responseMessage(0, "Something went wrong while logout, please try again.", "False");
    }

    }

    public function addLocation()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $cover_image = $_FILES['cover_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_name'=>$location_name,
                'adress'=>$adress,
                'lat'=>$lat,
                'lng'=>$lng,
                'cover_image'=>$cover_image
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                    

                if($cover_image!="" && $cover_image!=NULL){
                    if (!file_exists('assets/cover_image/')) {
                        mkdir('assets/cover_image/', 0777, true);
                    }

                    $ext= pathinfo($cover_image, PATHINFO_EXTENSION);
                    $newname=uniqid()."_coverimage_".time().".".$ext;
                    $tmpname=$_FILES['cover_image']['tmp_name'];
                    move_uploaded_file($tmpname, "assets/cover_image/".$newname);
                }
                else{
                  $newname="";
                }

              $id = $this->model->insert("location_master",array("user_id"=>$user_id,"location_name"=>$location_name,"adress"=>$adress,"lat"=>$lat,"lng"=>$lng,"cover_image"=>$newname,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));

              /*$coverimageurl = base_url().'assets/cover_image/';
              $newlocation = $this->model->sel_fld_row("*,IF(cover_image != '',concat('$coverimageurl', cover_image),'') as cover_image","location_master",array("location_id"=>$id));
              
              $newlocation->listof_routes = array();*/

              $data['data']=new stdClass();
              return comman_controller::successResponse($data,1,'Location added successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding location, please try again.", "False");
        }

    }

    public function deleteLocation()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_id'=>$location_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                
                $chkLocation=$this->model->sel_row('location_master',array("location_id"=>$location_id));
                if (count($chkLocation)>0) {

                  $this->model->delete("route_master",array("location_id"=>$location_id));
                  $this->model->delete("location_master",array("location_id"=>$location_id));

                  return comman_controller::successResponse($data,1,'Location deleted successfully','True');
                }
                else
                {
                  return comman_controller::responseMessage(0,'Invalid location_id','False');
                }

            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding route, please try again.", "False");
        }

    }

    public function addRoute()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_id'=>$location_id,
                'route_name'=>$route_name,
                'grade_opinion'=>$grade_opinion,
                'ratting'=>$ratting
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                $chkLocation=$this->model->sel_row('location_master',array("location_id"=>$location_id));
                if (count($chkLocation)>0) {

                  $route_image = $_FILES['route_image']['name'];
                  if($route_image!="" && $route_image!=NULL){
                      if (!file_exists('assets/route_image/')) {
                          mkdir('assets/route_image/', 0777, true);
                      }

                      $ext= pathinfo($route_image, PATHINFO_EXTENSION);
                      $newname=uniqid()."_routeimage_".time().".".$ext;
                      $tmpname=$_FILES['route_image']['tmp_name'];
                      move_uploaded_file($tmpname, "assets/route_image/".$newname);
                  }
                  else{
                    $newname="";
                  }

                $id = $this->model->insert("route_master",array("user_id"=>$user_id,"location_id"=>$location_id,"route_name"=>$route_name,"grade_opinion"=>$grade_opinion,"photo"=>$newname,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));

                $rat_id = $this->model->insert("route_ratting_master",array("route_id"=>$id,"user_id"=>$user_id,"ratting"=>$ratting,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));

                /*$routeimagepath = base_url().'assets/route_image/';
                $newroute = $this->model->sel_fld_row("*,IF(photo != '',concat('$routeimagepath', photo),'') as photo","route_master",array("route_id"=>$id));
                $allRatting = $this->model->sel_fld_row("AVG(ratting) as averageratting","route_ratting_master",array("route_id"=>$id));

                $newroute->ratting = number_format($allRatting->averageratting,2);*/

                $data['data']=new stdClass();
                return comman_controller::successResponse($data,1,'Route added successfully','True');  
                }
                else
                {
                  return comman_controller::responseMessage(0,'Invalid location_id','False');
                }   
                  
            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding route, please try again.", "False");
        }

    }

    public function giveRouteRatting()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'route_id'=>$route_id,
                'ratting'=>$ratting,
                'comments'=>$comments
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                $chkRoutes=$this->model->sel_row('route_master',array("route_id"=>$route_id));
                if (count($chkRoutes)>0) {
                  $chkRoutesrating=$this->model->sel_row('route_ratting_master',array("route_id"=>$route_id,"user_id"=>$user_id));
                  if (count($chkRoutesrating)>0) {
                    $rat_id = $chkRoutesrating->ratting_id;
                    $this->model->update("route_ratting_master",array("route_id"=>$route_id,"user_id"=>$user_id,"ratting"=>$ratting,"updated_date"=>cur_date_time),array("ratting_id"=>$rat_id)); //,"comments"=>$comments
                    
                  }
                  //else
                 // {
                    $rat_id = $this->model->insert("route_ratting_master",array("route_id"=>$route_id,"user_id"=>$user_id,"ratting"=>$ratting,"comments"=>$comments,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));
                 // }
                  
                
                $allRatting = $this->model->sjoin2_row("rm.user_id,um.fname,um.lname,rm.ratting,rm.comments","route_ratting_master rm","user_master um","um.user_id=rm.user_id",array("ratting_id"=>$rat_id));

                $allRatting->ratting = number_format($allRatting->ratting,2);

                $data['data']=$allRatting;
                return comman_controller::successResponse($data,1,'Comment added successfully','True');  
                }
                else
                {
                  return comman_controller::responseMessage(0,'Invalid route_id','False');
                }   
                  
            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding route, please try again.", "False");
        }

    }

    public function deleteRoute()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'route_id'=>$route_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                
                $chkRoute=$this->model->sel_row('route_master',array("route_id"=>$route_id));
                if (count($chkRoute)>0) {
                  
                  //unlink("assets/route_image/".$chkRoute->photo);

                  $this->model->delete("route_master",array("route_id"=>$route_id));
                  $this->model->delete("route_ratting_master",array("route_id"=>$route_id));

                  return comman_controller::successResponse($data,1,'Route deleted successfully','True');
                }
                else
                {
                  return comman_controller::responseMessage(0,'Invalid route_id','False');
                }

            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding route, please try again.", "False");
        }

    }

    public function getRoutes()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $cover_image = $_FILES['cover_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                //'user_id'=>$user_id,
                'location_id'=>$location_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              /*$count_user=$this->model->record_count('user_master',array("user_id"=>$user_id));  
                        
             if($count_user>0){*/
              $routeimagepath = base_url().'assets/route_image/';
              $routeslist = $this->model->sel_fld_res("route_id,route_name,grade_opinion,IF(photo != '',concat('$routeimagepath', photo),'') as photo,user_id","route_master",array("location_id"=>$location_id,"is_admin_confirm"=>1));
              foreach ($routeslist as $key => $value) {
                
                  /*if ($value->photo != "" && $value->photo != NULL) {
                    $value->photo = base_url().'assets/route_image/'.$value->photo;
                  }
                  else
                  {
                    $value->photo = "";
                  }*/
                  $allRatting = $this->model->sel_fld_row("AVG(ratting) as averageratting","route_ratting_master",array("route_id"=>$value->route_id)); //,"user_id"=>$value->user_id

                  $value->ratting = number_format($allRatting->averageratting,2);
                 
              }
              $data['data']=$routeslist;

              return comman_controller::successResponse($data,1,'get Routes successfully','True');    
            /*}
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }*/    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }

    public function getLocations()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $cover_image = $_FILES['cover_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                //'user_id'=>$user_id,
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              /*$count_user=$this->model->record_count('user_master',array("user_id"=>$user_id));  
                        
             if($count_user>0){*/
              $imageurl = base_url().'assets/cover_image/';
              
              $locationlist = $this->model->sel_fld_res("*,IF(cover_image != '',concat('$imageurl', cover_image),'') as cover_image","location_master",array("is_admin_confirm"=>1));
              foreach ($locationlist as $key => $value) {
               

                $getUser=$this->model->sel_row("user_master",array("user_id"=>$value->user_id));
                $value->fname = $getUser->fname;
                $value->lname = $getUser->lname;
                $routeimagepath = base_url().'assets/route_image/';
                $routelist = $this->model->sel_fld_res("route_id,route_name,grade_opinion,IF(photo != '',concat('$routeimagepath', photo),'') as photo,user_id","route_master",array("location_id"=>$value->location_id,"is_admin_confirm"=>1));
                if ($routelist != "" && $routelist != NULL) {
                  foreach ($routelist as $key => $routevalue) {
                   
                    $allRatting = $this->model->sel_fld_row("(ratting) as averageratting","route_ratting_master",array("route_id"=>$routevalue->route_id,"user_id"=>$routevalue->user_id));

                    $routevalue->ratting = number_format($allRatting->averageratting,2);

                  }
                  $value->listof_routes = $routelist;
                }
                else
                {
                  $value->listof_routes = array();
                }
                
              }
              $data['data']=$locationlist;

              return comman_controller::successResponse($data,1,'get Location successfully','True');    
            /*}
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }*/    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }
    
    public function getComments()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $cover_image = $_FILES['cover_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'route_id'=>$route_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_route=$this->model->record_count('route_master',array("route_id"=>$route_id,"is_admin_confirm"=>1));

                        
             if($count_route>0){
              $getRoutes=$this->model->sel_row('route_master',array("route_id"=>$route_id,"is_admin_confirm"=>1));

              $rattinglist = $this->model->sjoin2_row_left_order("rm.user_id,um.fname,um.lname,rm.ratting,rm.comments","route_ratting_master rm","user_master um","um.user_id=rm.user_id",array("route_id"=>$route_id),"ratting_id","desc");//,"rm.user_id"=>$user_id
              $data['data']=$rattinglist;
              
              $userratting = $this->model->sjoin2_row_left_order("rm.user_id,um.fname,um.lname,IF(rm.ratting != '',rm.ratting,0) as ratting,rm.comments","route_ratting_master rm","user_master um","um.user_id=rm.user_id",array("route_id"=>$route_id,"rm.user_id"=>$user_id),"ratting_id","desc");
              if ($userratting[0] == "" || $userratting[0] == NULL) {
                $data['user_ratting']=new stdClass();
              }else
              {
                $data['user_ratting']=$userratting[0];
              }
              $data['grade_opinion']=$getRoutes->grade_opinion;

              return comman_controller::successResponse($data,1,'get Comments successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid Route id.", "False");
            }   
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }
    
    public function addApproach()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $approach_image = $_FILES['approach_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_id'=>$location_id,
                'approach_image'=>$approach_image,
                'session_time'=>$session_time
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_location=$this->model->record_count('location_master',array("location_id"=>$location_id,"is_admin_confirm"=>1));

                        
             if($count_location>0){
              
              $approach_image = $_FILES['approach_image']['name'];
              if($approach_image!="" && $approach_image!=NULL){
                  if (!file_exists('assets/approach_image/')) {
                      mkdir('assets/approach_image/', 0777, true);
                  }

                  $ext= pathinfo($approach_image, PATHINFO_EXTENSION);
                  $newname=uniqid()."_routeimage_".time().".".$ext;
                  $tmpname=$_FILES['approach_image']['tmp_name'];
                  move_uploaded_file($tmpname, "assets/approach_image/".$newname);
              }
              else{
                $newname="";
              }

              $id = $this->model->insert("approach_master",array("user_id"=>$user_id,"location_id"=>$location_id,"date"=>$date,"session_time"=>$session_time,"image"=>$newname,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));

              $approachimagepath = base_url().'assets/approach_image/';
              $newapproach = $this->model->sjoin2_row("am.user_id,am.approach_id,am.date,um.fname,um.lname,am.session_time,,IF(am.image != '',concat('$approachimagepath', am.image),'') as image","approach_master am","user_master um","um.user_id=am.user_id",array("approach_id"=>$id));
              $data['data']=$newapproach;

              return comman_controller::successResponse($data,1,'Approach added successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid Location id.", "False");
            }   
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }

    public function updateApproach()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $approach_image = $_FILES['approach_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_id'=>$location_id,
                'approach_id'=>$approach_id,
                'session_time'=>$session_time
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_approach=$this->model->record_count('approach_master',array("approach_id"=>$approach_id));

                        
             if($count_approach>0){

              $getapproach=$this->model->sel_row('approach_master',array("approach_id"=>$approach_id));

              $approach_image = $_FILES['approach_image']['name'];
              if($approach_image!="" && $approach_image!=NULL){
                  if (!file_exists('assets/approach_image/')) {
                      mkdir('assets/approach_image/', 0777, true);
                  }

                  $ext= pathinfo($approach_image, PATHINFO_EXTENSION);
                  $newname=uniqid()."_routeimage_".time().".".$ext;
                  $tmpname=$_FILES['approach_image']['tmp_name'];
                  move_uploaded_file($tmpname, "assets/approach_image/".$newname);
              }
              else{
                $newname=$getapproach->image;
              }

              $this->model->update("approach_master",array("user_id"=>$user_id,"date"=>$date,"location_id"=>$location_id,"session_time"=>$session_time,"image"=>$newname,"updated_date"=>cur_date_time),array("approach_id"=>$approach_id));

              $approachimagepath = base_url().'assets/approach_image/';
              $newapproach = $this->model->sjoin2_row("am.user_id,am.approach_id,am.date,um.fname,um.lname,am.session_time,,IF(am.image != '',concat('$approachimagepath', am.image),'') as image","approach_master am","user_master um","um.user_id=am.user_id",array("approach_id"=>$approach_id));
              $data['data']=$newapproach;

              return comman_controller::successResponse($data,1,'Approach updated successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid Approach id.", "False");
            }   
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }

    public function deleteApproach()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $approach_image = $_FILES['approach_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'approach_id'=>$approach_id,
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_approach=$this->model->record_count('approach_master',array("approach_id"=>$approach_id));

                        
             if($count_approach>0){

              $getapproach=$this->model->sel_row('approach_master',array("approach_id"=>$approach_id));
              unlink('assets/approach_image/'.$getapproach->image);
              $this->model->delete("approach_master",array("approach_id"=>$approach_id));
              
              return comman_controller::successResponse($data,1,'Approach deleted successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid Approach id.", "False");
            }   
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }

    public function getapproach()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            $cover_image = $_FILES['cover_image']['name'];

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'location_id'=>$location_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_location=$this->model->record_count('location_master',array("location_id"=>$location_id,"is_admin_confirm"=>1));

                        
             if($count_location>0){
              $approachimagepath = base_url().'assets/approach_image/';

              $approachlist = $this->model->sjoin2_row_left_order("am.user_id,am.approach_id,am.date,um.fname,um.lname,am.session_time,,IF(am.image != '',concat('$approachimagepath', am.image),'') as image","approach_master am","user_master um","um.user_id=am.user_id",array("location_id"=>$location_id,"am.user_id"=>$user_id),"approach_id","desc");
              $data['data']=$approachlist;

              return comman_controller::successResponse($data,1,'get Approach successfully','True');    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid Location id.", "False");
            }   
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }

    }
    
    public function getVouchers()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            
            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              
              $voucherimagepath = base_url().'assets/voucher_image/';

              $voucherlist = $this->model->sel_fld_res("voucher_id,voucher_name,voucher_code,discount,points,is_delete,IF(voucher_image != '',concat('$voucherimagepath', voucher_image),'') as voucher_image","voucher_master",array("is_delete"=>0));
              $voucherarr = array();
              foreach ($voucherlist as $key => $value) {
                $getUserVoucher = $this->model->sel_fld_row("*","user_voucher_master",array("voucher_id"=>$value->voucher_id,"user_id"=>$user_id));
                if (count($getUserVoucher)>0) {
                  $value->is_purchase = "1";
                  
                }
                else
                {
                  $value->is_purchase = "0";
                }
                if (count($getUserVoucher)>0 || $value->is_delete==0) {
                    unset($value->is_delete);
                  $voucherarr[] = $value;
                }
              }
              $data['data']=$voucherarr;

              return comman_controller::successResponse($data,1,'get Vouchers successfully','True');    
             
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }
    }

    public function purchaseVouchers()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            
            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'voucher_id'=>$voucher_id,
                'points'=>$points
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
            $get_user=$this->model->sel_row('user_master',array("user_id"=>$user_id,"is_delete"=>0));

                        
            if(count($get_user)>0){
              $count_voucher=$this->model->record_count('voucher_master',array("voucher_id"=>$voucher_id,"is_delete"=>0));
              if ($count_voucher>0) {
                if ($get_user->reward_point >= $points) {
                    $id = $this->model->insert("user_voucher_master",array("user_id"=>$user_id,"voucher_id"=>$voucher_id,"points"=>$points,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));
                    $this->model->update("user_master",array("reward_point"=>$get_user->reward_point - $points,"updated_date"=>cur_date_time),array("user_id"=>$user_id));

                    $get_newpoints=$this->model->sel_row('user_master',array("user_id"=>$user_id));
                    $data['reward_point']=$get_newpoints->reward_point;

                    $voucherimagepath = base_url().'assets/voucher_image/';

                    $voucherlist = $this->model->sel_fld_res("voucher_id,voucher_name,voucher_code,discount,points,IF(voucher_image != '',concat('$voucherimagepath', voucher_image),'') as voucher_image","voucher_master",array("is_delete"=>0));
                    foreach ($voucherlist as $key => $value) {
                      $getUserVoucher = $this->model->sel_fld_row("*","user_voucher_master",array("voucher_id"=>$value->voucher_id,"user_id"=>$user_id));
                      if (count($getUserVoucher)>0) {
                        $value->is_purchase = "1";
                      }
                      else
                      {
                        $value->is_purchase = "0";
                      }
                    }
                    $data['data']=$voucherlist;

                    return comman_controller::successResponse($data,1,'Voucher purchase successfully','True');
                }
                else
                {
                  return comman_controller::responseMessage(0, "No sufficent points in your account.", "False");
                }
                
              }
              else
              {
                return comman_controller::responseMessage(0, "Invalid Voucher id.", "False");
              }
    
            }
            else{
                return comman_controller::responseMessage(0, "Invalid user id.", "False");
            }
             
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong , please try again.", "False");
        }
    }
    
    public function giveRouteRattingOnly()
    {
        try{
            comman_controller::varifyMethod("POST");
            extract($_POST);
            
            $key = empty($_SERVER["HTTP_KEY"]) ? "" : $_SERVER["HTTP_KEY"];
            $token = empty($_SERVER["HTTP_TOKEN"]) ? "" : $_SERVER["HTTP_TOKEN"];
            

            comman_controller::requiredValidation([
                'key' => $key,
                'token' => $token,
                'user_id'=>$user_id,
                'route_id'=>$route_id,
                'ratting'=>$ratting
             ]);

            if($this->model->checkKeyExist($key)==0){
              return comman_controller::responseMessage(0, "Please enter correct key, eneterd key doesn’t match with provided key.", "False");
            }
            else if($this->model->checkKeyTokenExist($key,$token)==0){
                return comman_controller::responseMessage(0, "You are not authorized to access associated web-services; it seems there is mismatch in key-token pair.", "False");
            }
               
              $count_user=$this->model->record_count('user_master',array("user_id"=>$user_id,"is_delete"=>0));  
                        
             if($count_user>0){
                $chkRoutes=$this->model->sel_row('route_master',array("route_id"=>$route_id));
                if (count($chkRoutes)>0) {
                  $chkRoutesrating=$this->model->sel_row('route_ratting_master',array("route_id"=>$route_id,"user_id"=>$user_id));
                  if (count($chkRoutesrating)>0) {
                    $rat_id = $chkRoutesrating->ratting_id;
                    $this->model->update("route_ratting_master",array("route_id"=>$route_id,"user_id"=>$user_id,"ratting"=>$ratting,"updated_date"=>cur_date_time),array("ratting_id"=>$rat_id));
                    
                  }
                  else
                  {
                    $rat_id = $this->model->insert("route_ratting_master",array("route_id"=>$route_id,"user_id"=>$user_id,"ratting"=>$ratting,"created_date"=>cur_date_time,"updated_date"=>cur_date_time));
                  }
                  
                
                $allRatting = $this->model->sjoin2_row("rm.user_id,um.fname,um.lname,rm.ratting,rm.comments","route_ratting_master rm","user_master um","um.user_id=rm.user_id",array("ratting_id"=>$rat_id));

                $allRatting->ratting = number_format($allRatting->ratting,2);

                $data['data']=$allRatting;
                return comman_controller::successResponse($data,1,'Rating added successfully','True');  
                }
                else
                {
                  return comman_controller::responseMessage(0,'Invalid route_id','False');
                }   
                  
            }
            else{
                return comman_controller::responseMessage(0, "Invalid user_id.", "False");
            }    
        } 
        catch (Exception $e) {
            return comman_controller::responseMessage(0, "Something went wrong while adding route, please try again.", "False");
        }

    }
    
      
 
}