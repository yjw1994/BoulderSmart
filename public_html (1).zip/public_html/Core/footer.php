<footer style="position: fixed;bottom: 0;text-align: center; width: 100% ">
			  <p style="color: #c14101; font-weight:bold; font-size: 17px; ">Copyright &copy; <?=date('Y')?><br/>
			  <?=servername;?>. All Rights Reserved.</p>
			</footer>